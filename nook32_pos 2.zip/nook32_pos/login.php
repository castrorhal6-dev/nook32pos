<?php
ini_set('display_errors', '1');
ini_set('display_startup_errors', '1');
error_reporting(E_ALL);

mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);

session_start();
require_once __DIR__ . '/config/database.php';

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';

    if ($username === '' || $password === '') {
        $error = 'Please enter your username and password.';
    } else {
        try {
            $stmt = $conn->prepare(
                "SELECT user_id, full_name, username, password, role
                 FROM users
                 WHERE username = ?
                 LIMIT 1"
            );

            $stmt->bind_param("s", $username);
            $stmt->execute();

            $stmt->bind_result(
                $userId,
                $fullName,
                $dbUsername,
                $hashedPassword,
                $role
            );

            if ($stmt->fetch() && password_verify($password, $hashedPassword)) {
                $stmt->close();

                session_regenerate_id(true);

                $_SESSION['user_id'] = $userId;
                $_SESSION['full_name'] = $fullName;
                $_SESSION['username'] = $dbUsername;
                $_SESSION['role'] = $role;

                header('Location: index.php');
                exit;
            }

            $stmt->close();
            $error = 'Invalid username or password.';

        } catch (Throwable $e) {
            error_log('Login error: ' . $e->getMessage());
            $error = 'A login error occurred. Please check the PHP error log.';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login | Nook32 Coffee</title>

    <style>
        * {
            box-sizing: border-box;
        }

        body {
            margin: 0;
            min-height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            padding: 20px;
            font-family: Arial, sans-serif;
            background: #f4eee6;
            color: #3b2920;
        }

        .login-container {
            width: 100%;
            max-width: 420px;
            padding: 35px;
            background: #fffdf9;
            border-radius: 16px;
            box-shadow: 0 8px 25px rgba(59, 41, 32, 0.12);
        }

        .brand {
            text-align: center;
            margin-bottom: 28px;
        }

        .brand h1 {
            margin-bottom: 8px;
            color: #6f4e37;
        }

        .brand p {
            margin: 0;
            color: #806e61;
        }

        label {
            display: block;
            margin: 16px 0 7px;
            font-weight: bold;
        }

        input {
            width: 100%;
            padding: 12px;
            border: 1px solid #d8c7b8;
            border-radius: 8px;
            font-size: 15px;
        }

        input:focus {
            outline: 2px solid #a67c52;
            border-color: #a67c52;
        }

        button {
            width: 100%;
            margin-top: 24px;
            padding: 13px;
            border: none;
            border-radius: 8px;
            background: #6f4e37;
            color: white;
            font-size: 16px;
            font-weight: bold;
            cursor: pointer;
        }

        button:hover {
            background: #543927;
        }

        .error {
            padding: 11px;
            margin-bottom: 16px;
            border-radius: 8px;
            background: #fbe9e7;
            color: #a12b21;
        }
    </style>
</head>

<body>
    <main class="login-container">
        <div class="brand">
            <h1>Nook32 Coffee</h1>
            <p>POS and Sales Management System</p>
        </div>

        <?php if ($error !== ''): ?>
            <div class="error">
                <?= htmlspecialchars($error, ENT_QUOTES, 'UTF-8') ?>
            </div>
        <?php endif; ?>

        <form method="POST" action="login.php">
            <label for="username">Username</label>
            <input
                type="text"
                id="username"
                name="username"
                autocomplete="username"
                required
            >

            <label for="password">Password</label>
            <input
                type="password"
                id="password"
                name="password"
                autocomplete="current-password"
                required
            >

            <button type="submit">Log In</button>
        </form>
    </main>
</body>
</html>