
<?php

require_once __DIR__ . '/auth.php';
requireLogin();

// Allow both admin and cashier to view order history.
$userRole = $_SESSION['role'] ?? '';

if (!in_array($userRole, ['admin', 'cashier'], true)) {
    http_response_code(403);
    exit('Access denied.');
}

require_once __DIR__ . '/config/database.php';

// Default to today's date.
$selectedDate = $_GET['date'] ?? date('Y-m-d');

// Validate date.
$dateObject = DateTime::createFromFormat('!Y-m-d', $selectedDate);

if (!$dateObject || $dateObject->format('Y-m-d') !== $selectedDate) {
    $selectedDate = date('Y-m-d');
}

// Retrieve orders for selected date.
$sql = "
    SELECT
        o.order_id,
        o.order_date,
        o.subtotal,
        o.discount_amount,
        o.total_amount,
        o.payment_method,
        o.payment_reference,
        o.payment_status,
        o.cash_received,
        o.change_amount,

        GROUP_CONCAT(
            CONCAT(oi.product_name, ' × ', oi.quantity)
            ORDER BY oi.order_item_id
            SEPARATOR ', '
        ) AS item_names

    FROM orders o

    LEFT JOIN order_items oi
        ON o.order_id = oi.order_id

    WHERE o.order_date >= ?
      AND o.order_date < DATE_ADD(?, INTERVAL 1 DAY)

    GROUP BY
        o.order_id,
        o.order_date,
        o.subtotal,
        o.discount_amount,
        o.total_amount,
        o.payment_method,
        o.payment_reference,
        o.payment_status,
        o.cash_received,
        o.change_amount

    ORDER BY o.order_date DESC
";

$stmt = $conn->prepare($sql);
$stmt->bind_param("ss", $selectedDate, $selectedDate);
$stmt->execute();

$result = $stmt->get_result();

function e($value): string
{
    return htmlspecialchars(
        (string) $value,
        ENT_QUOTES,
        'UTF-8'
    );
}

$message = $_GET['message'] ?? '';

?>

<!DOCTYPE html>
<html lang="en">
<head>

<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>Nook32 Coffee | Order History</title>

<style>
* {
    box-sizing: border-box;
}

body {
    margin: 0;
    font-family: Arial, sans-serif;
    background: #f7f1e8;
    color: #39271f;
}

/* HEADER */

.main-header {
    background: #39271f;
    color: #fff8ed;
    padding: 22px 6%;
    display: flex;
    justify-content: space-between;
    align-items: center;
    gap: 20px;
    flex-wrap: wrap;
    box-shadow: 0 3px 12px rgba(0,0,0,0.15);
}

.brand {
    display: flex;
    align-items: center;
    gap: 15px;
}

.logo {
    width: 75px;
    height: 75px;
    object-fit: contain;
    mix-blend-mode: screen;
}

.brand-text h1 {
    margin: 0;
    font-size: 27px;
}

.brand-text p {
    margin: 7px 0 0;
    color: #dfcbb7;
}

.header-actions {
    display: flex;
    align-items: center;
    gap: 12px;
    flex-wrap: wrap;
}

.role-badge,
.pos-badge,
.logout-btn {
    display: inline-block;
    padding: 12px 20px;
    border: 1px solid #a98a70;
    border-radius: 30px;
    color: #fff8ed;
    text-decoration: none;
    font-weight: bold;
    white-space: nowrap;
}

.role-badge,
.pos-badge {
    background: transparent;
}

.role-badge {
    border: none;
    border-radius: 0;
    background: transparent;
    color: #fff8ed;
    padding: 0;
    font-weight: bold;
    font-size: 16px;
    cursor: default;
}

.logout-btn {
    background: #fff8ed;
    color: #39271f;
}

.logout-btn:hover {
    background: #dfcbb7;
}

/* NAVIGATION */

.navbar {
    position: relative;
    z-index: 10;
    display: flex;
    justify-content: center;
    align-items: center;
    gap: 12px;
    flex-wrap: wrap;
    padding: 14px 20px;
    background: #f7f1e8;
    border-bottom: 1px solid #dfcbb7;
}

.navbar a {
    display: inline-block;
    padding: 10px 20px;
    border: 1px solid #b99a79;
    border-radius: 30px;
    color: #39271f;
    text-decoration: none;
    font-weight: bold;
    transition: 0.2s ease;
}

.navbar a:hover,
.navbar a.active {
    background: #654633;
    color: #fffdf9;
    border-color: #654633;
}

/* MAIN CONTENT */

.container {
    max-width: 1500px;
    margin: 35px auto 50px;
    padding: 0 25px;
}

.card {
    padding: 25px;
    background: #fffdf9;
    border: 1px solid #dfcbb7;
    border-radius: 16px;
    box-shadow: 0 4px 12px rgba(57, 39, 31, 0.06);
}

h2 {
    margin-top: 0;
}

.notice {
    margin: 15px 0;
    color: #654633;
    font-size: 14px;
}

/* DATE FILTER */

.date-filter-card {
    display: flex;
    justify-content: space-between;
    align-items: center;
    flex-wrap: wrap;
    gap: 20px;
    margin: 22px 0;
    padding: 22px;
    background: #fffdf9;
    border: 1px solid #dfcbb7;
    border-radius: 14px;
    box-shadow: 0 4px 12px rgba(57, 39, 31, 0.05);
}

.date-filter-heading {
    display: flex;
    align-items: center;
    gap: 12px;
}

.date-filter-icon {
    display: flex;
    align-items: center;
    justify-content: center;
    width: 46px;
    height: 46px;
    background: #f7f1e8;
    border-radius: 12px;
    font-size: 22px;
}

.date-filter-heading h3 {
    margin: 0 0 5px;
    color: #39271f;
    font-size: 17px;
}

.date-filter-heading p {
    margin: 0;
    color: #8a7565;
    font-size: 13px;
}

.date-filter-form {
    display: flex;
    align-items: flex-end;
    flex-wrap: wrap;
    gap: 10px;
}

.date-input-group {
    display: flex;
    flex-direction: column;
    gap: 7px;
}

.date-input-group label {
    color: #654633;
    font-size: 12px;
    font-weight: bold;
    text-transform: uppercase;
    letter-spacing: 0.5px;
}

.date-input-group input {
    min-height: 42px;
    padding: 10px 12px;
    border: 1px solid #dfcbb7;
    border-radius: 8px;
    background: #fff;
    color: #39271f;
    font-family: Arial, sans-serif;
    font-size: 14px;
}

.date-input-group input:focus {
    outline: none;
    border-color: #654633;
    box-shadow: 0 0 0 3px rgba(101, 70, 51, 0.12);
}

.filter-btn,
.today-btn {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    min-height: 42px;
    padding: 10px 18px;
    border-radius: 8px;
    font-size: 14px;
    font-weight: bold;
    text-decoration: none;
    cursor: pointer;
    transition: 0.2s ease;
}

.filter-btn {
    border: 1px solid #39271f;
    background: #39271f;
    color: #fffdf9;
}

.filter-btn:hover {
    background: #654633;
    border-color: #654633;
}

.today-btn {
    border: 1px solid #dfcbb7;
    background: #f7f1e8;
    color: #39271f;
}

.today-btn:hover {
    background: #dfcbb7;
}

/* TABLE */

.table-wrapper {
    width: 100%;
    overflow-x: auto;
}

table {
    width: 100%;
    min-width: 1250px;
    border-collapse: collapse;
}

th,
td {
    padding: 14px 12px;
    border-bottom: 1px solid #eadfd2;
    text-align: left;
    vertical-align: middle;
    font-size: 14px;
}

th {
    background: #f7f1e8;
    color: #39271f;
    white-space: nowrap;
}

tbody tr:hover {
    background: #fff8ed;
}

.discount-cell {
    color: #28643c;
    font-weight: bold;
}

.total-cell {
    font-weight: bold;
    color: #39271f;
}

/* PAYMENT STATUS */

.status {
    display: inline-block;
    padding: 6px 10px;
    border-radius: 20px;
    font-size: 12px;
    font-weight: bold;
    text-transform: uppercase;
}

.status.paid {
    background: #dcefdc;
    color: #24632b;
}

.status.pending {
    background: #fff0c2;
    color: #795b00;
}

.status.failed {
    background: #f8d7da;
    color: #842029;
}

/* VERIFY PAYMENT */

.verify-form {
    margin: 0;
}

.verify-btn {
    padding: 8px 12px;
    border: none;
    border-radius: 8px;
    background: #654633;
    color: white;
    font-weight: bold;
    cursor: pointer;
}

.verify-btn:hover {
    background: #39271f;
}

/* MESSAGES */

.message {
    margin-bottom: 20px;
    padding: 12px 16px;
    border-radius: 8px;
    background: #fff8ed;
    border: 1px solid #dfcbb7;
}

.empty {
    padding: 25px;
    text-align: center;
    color: #654633;
}

/* FOOTER */

.site-footer {
    background: #39271f;
    color: #fffdf9;
    padding: 40px 7% 15px;
    margin-top: 50px;
}

.footer-content {
    display: flex;
    justify-content: space-between;
    align-items: flex-start;
    flex-wrap: wrap;
    gap: 35px;
    max-width: 1200px;
    margin: auto;
}

.footer-content h2 {
    margin: 0 0 10px;
    font-size: 22px;
}

.footer-content h3 {
    font-size: 15px;
    margin-bottom: 15px;
    color: #d7b998;
}

.footer-content p {
    color: #dfcbb7;
    font-size: 14px;
}

.social-icons {
    display: flex;
    gap: 12px;
}

.social-icons a {
    width: 40px;
    height: 40px;
    border-radius: 50%;
    background: #fffdf9;
    color: #654633;
    display: flex;
    justify-content: center;
    align-items: center;
    transition: 0.3s;
}

.social-icons a:hover {
    background: #d7b998;
    transform: translateY(-4px);
}

.social-icons svg {
    width: 21px;
    height: 21px;
    fill: currentColor;
    stroke: currentColor;
    stroke-width: 1.8;
}

.footer-bottom {
    border-top: 1px solid #765b48;
    text-align: center;
    margin-top: 30px;
    padding-top: 15px;
}

.footer-bottom p {
    font-size: 12px;
    color: #cbb8a7;
}

/* RESPONSIVE */

@media (max-width: 700px) {

    .main-header {
        padding: 18px 5%;
    }

    .header-actions {
        width: 100%;
    }

    .navbar {
        gap: 8px;
    }

    .navbar a {
        padding: 9px 13px;
        font-size: 13px;
    }

    .container {
        padding: 0 15px;
        margin-top: 25px;
    }

    .card {
        padding: 18px;
    }

    .date-filter-card {
        align-items: stretch;
    }

    .date-filter-form {
        width: 100%;
    }

    .date-input-group {
        width: 100%;
    }

    .date-input-group input {
        width: 100%;
    }

    .filter-btn,
    .today-btn {
        flex: 1;
    }

    .footer-content {
        flex-direction: column;
        gap: 20px;
    }
}

@media (max-width: 450px) {

    .logo {
        width: 60px;
        height: 60px;
    }

    .brand-text h1 {
        font-size: 21px;
    }

    .role-badge,
    .pos-badge,
    .logout-btn {
        padding: 9px 13px;
        font-size: 12px;
    }
}
</style>

</head>

<body>

<!-- HEADER -->

<header class="main-header">

    <div class="brand">

        <img
            src="assets/images/logo.png"
            alt="Nook32 Coffee Logo"
            class="logo"
        >

        <div class="brand-text">
            <h1>NOOK32 COFFEE</h1>
            <p>Good coffee, cozy moments.</p>
        </div>

    </div>

    <div class="header-actions">

        <span class="role-badge">
            <?= e(ucfirst($userRole)) ?>
        </span>


        <a href="logout.php" class="logout-btn">
            Logout
        </a>

    </div>

</header>

<!-- NAVIGATION -->

<nav class="navbar">

    <a href="order_history.php" class="active">
        Order History
    </a>

    <?php if ($userRole === 'admin'): ?>

         <a href="index.php">POS Menu</a>

        <a href="dashboard.php">Sales Dashboard</a>

        <a href="inventory.php">Inventory</a>

        <a href="manage_users.php">Manage Users</a>

    <?php endif; ?>

</nav>

<!-- MAIN CONTENT -->

<main class="container">

    <section class="card">

        <h2>Order History</h2>

        <?php if ($message === 'verified'): ?>

            <div class="message">
                QR payment marked as paid successfully.
            </div>

        <?php elseif ($message === 'unchanged'): ?>

            <div class="message">
                This order could not be updated. It may already be paid
                or may not be a pending QR order.
            </div>

        <?php elseif ($message === 'invalid'): ?>

            <div class="message">
                Invalid order ID.
            </div>

        <?php elseif ($message === 'error'): ?>

            <div class="message">
                An error occurred while updating the payment.
                Please try again.
            </div>

        <?php endif; ?>

        <p class="notice">
            Before verifying a QR payment, confirm that the payment
            was actually received.
        </p>

        <!-- DATE FILTER -->

        <div class="date-filter-card">

            <div class="date-filter-heading">

                <span class="date-filter-icon">📅</span>

                <div>
                    <h3>Filter Order History</h3>
                    <p>Choose a date to view your orders.</p>
                </div>

            </div>

            <form method="GET" class="date-filter-form">

                <div class="date-input-group">

                    <label for="date">Order Date</label>

                    <input
                        type="date"
                        id="date"
                        name="date"
                        value="<?= e($selectedDate) ?>"
                        required
                    >

                </div>

                <button type="submit" class="filter-btn">
                    View Orders
                </button>

                <a href="order_history.php" class="today-btn">
                    Today
                </a>

            </form>

        </div>

        <!-- ORDERS TABLE -->

        <div class="table-wrapper">

            <table>

                <thead>

                    <tr>
                        <th>Order ID</th>
                        <th>Date and Time</th>
                        <th>Items Ordered</th>
                        <th>Subtotal</th>
                        <th>Discount</th>
                        <th>Total</th>
                        <th>Payment</th>
                        <th>E-Wallet Reference No.</th>
                        <th>Cash Received</th>
                        <th>Change</th>
                        <th>Status</th>
                    </tr>

                </thead>

                <tbody>

                <?php if ($result->num_rows > 0): ?>

                    <?php while ($order = $result->fetch_assoc()): ?>

                        <tr>

                            <td>
                                #<?= e($order['order_id']) ?>
                            </td>

                            <td>
                                <?= e(date(
                                    'M d, Y h:i A',
                                    strtotime($order['order_date'])
                                )) ?>
                            </td>

                            <td>
                                <?= e($order['item_names'] ?? 'No items') ?>
                            </td>

                            <!-- SUBTOTAL -->

                            <td>
                                ₱<?= number_format(
                                    (float) $order['subtotal'],
                                    2
                                ) ?>
                            </td>

                            <!-- DISCOUNT -->

                            <td class="discount-cell">

                                <?php
                                $discount = (float) $order['discount_amount'];
                                ?>

                                <?php if ($discount > 0): ?>

                                    −₱<?= number_format($discount, 2) ?>

                                <?php else: ?>

                                    —

                                <?php endif; ?>

                            </td>

                            <!-- FINAL TOTAL -->

                            <td class="total-cell">
                                ₱<?= number_format(
                                    (float) $order['total_amount'],
                                    2
                                ) ?>
                            </td>

                            <!-- PAYMENT METHOD -->

                            <td>
                                <?= e(strtoupper($order['payment_method'])) ?>
                            </td>

                            <!-- PAYMENT REFERENCE -->

                            <td>

                                <?php if ($order['payment_method'] === 'qr'): ?>

                                    <?= e(
                                        $order['payment_reference']
                                        ?: 'No reference'
                                    ) ?>

                                <?php else: ?>

                                    —

                                <?php endif; ?>

                            </td>

                            <!-- CASH RECEIVED -->

                            <td>

                                <?php if ($order['cash_received'] !== null): ?>

                                    ₱<?= number_format(
                                        (float) $order['cash_received'],
                                        2
                                    ) ?>

                                <?php else: ?>

                                    —

                                <?php endif; ?>

                            </td>

                            <!-- CHANGE -->

                            <td>

                                <?php if ($order['change_amount'] !== null): ?>

                                    ₱<?= number_format(
                                        (float) $order['change_amount'],
                                        2
                                    ) ?>

                                <?php else: ?>

                                    —

                                <?php endif; ?>

                            </td>

                            <!-- PAYMENT STATUS -->

                            <td>

                                <span class="status <?= e(
                                    $order['payment_status']
                                ) ?>">

                                    <?= e(strtoupper(
                                        $order['payment_status']
                                    )) ?>

                                </span>

                            </td>

                        </tr>

                    <?php endwhile; ?>

                <?php else: ?>

                    <tr>
                        <td colspan="12" class="empty">

                            No orders found for
                            <?= e(date('F d, Y', strtotime($selectedDate))) ?>.

                        </td>
                    </tr>

                <?php endif; ?>

                </tbody>

            </table>

        </div>

    </section>

</main>

<!-- FOOTER -->

<footer class="site-footer">

    <div class="footer-content">

        <div class="footer-brand">
            <h3>NOOK32 COFFEE ☕</h3>
            <p>Good coffee, cozy moments.</p>
        </div>

        <div class="footer-location">
            <h3>VISIT OUR SHOP</h3>
            <p>📍 No. 5 Mckinley St., Binmaley, Pangasinan</p>
        </div>

        <div class="footer-social">

            <h3>FOLLOW US</h3>

            <div class="social-icons">

                <!-- FACEBOOK -->

                <a
                    href="https://facebook.com/nook32coffee"
                    target="_blank"
                    rel="noopener noreferrer"
                    aria-label="Facebook"
                >
                    <svg viewBox="0 0 24 24">
                        <path d="M13.5 21v-8h2.7l.4-3h-3.1V8.1c0-.9.3-1.5 1.6-1.5h1.7V3.9c-.3 0-1.3-.1-2.5-.1-2.5 0-4.2 1.5-4.2 4.3V10H7.5v3h2.6v8z"/>
                    </svg>
                </a>

                <!-- INSTAGRAM -->

                <a
                    href="https://instagram.com/nook32coffee"
                    target="_blank"
                    rel="noopener noreferrer"
                    aria-label="Instagram"
                >
                    <svg viewBox="0 0 24 24">
                        <rect x="3" y="3" width="18" height="18" rx="5"/>
                        <circle cx="12" cy="12" r="4"/>
                        <circle cx="17.5" cy="6.5" r="1" fill="currentColor" stroke="none"/>
                    </svg>
                </a>

                <!-- TIKTOK -->

                <a
                    href="https://tiktok.com/@nook32coffee"
                    target="_blank"
                    rel="noopener noreferrer"
                    aria-label="TikTok"
                >
                    <svg viewBox="0 0 24 24">
                        <path d="M14 3v11.2a3.2 3.2 0 1 1-3-3.2V8a6.2 6.2 0 1 0 6.2 6.2V9.1c1.3 1 2.8 1.5 4.3 1.6V7.5c-2.4-.2-4.1-1.8-4.5-4.5z"/>
                    </svg>
                </a>

            </div>

        </div>

    </div>

    <div class="footer-bottom">
        <p>
            © <?= date('Y') ?> Nook32 Coffee. All Rights Reserved.
        </p>
    </div>

</footer>

</body>
</html>
