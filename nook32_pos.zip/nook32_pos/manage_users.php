
<?php

require_once __DIR__ . '/auth.php';
requireRole('admin');

require_once __DIR__ . '/config/database.php';

$userRole = $_SESSION['role'] ?? 'admin';

$sql = "SELECT user_id, full_name, username, role, created_at
        FROM users
        ORDER BY user_id ASC";

$result = $conn->query($sql);

function e($value): string
{
    return htmlspecialchars(
        (string) $value,
        ENT_QUOTES,
        'UTF-8'
    );
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Nook32 Coffee | Manage Users</title>

<style>
* {
    box-sizing: border-box;
}

body {
    margin: 0;
    font-family: Arial, sans-serif;
    background: #f7f1e8;
    color: #39271f;
}

/* HEADER */

.main-header {
    background: #39271f;
    color: #fff8ed;
    padding: 22px 6%;
    display: flex;
    justify-content: space-between;
    align-items: center;
    gap: 20px;
    flex-wrap: wrap;
    box-shadow: 0 3px 12px rgba(0,0,0,0.15);
}

.brand {
    display: flex;
    align-items: center;
    gap: 15px;
}

.logo {
    width: 75px;
    height: 75px;
    object-fit: contain;
    mix-blend-mode: screen;
}

.brand-text h1 {
    margin: 0;
    font-size: 27px;
}

.brand-text p {
    margin: 7px 0 0;
    color: #dfcbb7;
}

.header-actions {
    display: flex;
    align-items: center;
    gap: 12px;
    flex-wrap: wrap;
}

.role-badge,
.pos-badge,
.logout-btn {
    display: inline-block;
    padding: 12px 20px;
    border: 1px solid #a98a70;
    border-radius: 30px;
    color: #fff8ed;
    text-decoration: none;
    font-weight: bold;
    white-space: nowrap;
}

.role-badge,
.pos-badge {
    background: transparent;
}

.role-badge {
    border: none;
    border-radius: 0;
    background: transparent;
    color: #fff8ed;
    padding: 0;
    font-weight: bold;
    font-size: 16px;
    cursor: default;
}

.logout-btn {
    background: #fff8ed;
    color: #39271f;
}

.logout-btn:hover {
    background: #dfcbb7;
}

/* NAVIGATION */

.navbar {
    position: relative;
    z-index: 10;
    display: flex;
    justify-content: center;
    align-items: center;
    gap: 12px;
    flex-wrap: wrap;
    padding: 14px 20px;
    background: #f7f1e8;
    border-bottom: 1px solid #dfcbb7;
}

.navbar a {
    display: inline-block;
    padding: 10px 20px;
    border: 1px solid #b99a79;
    border-radius: 30px;
    color: #39271f;
    text-decoration: none;
    font-weight: bold;
    transition: 0.2s ease;
}

.navbar a:hover,
.navbar a.active {
    background: #654633;
    color: #fffdf9;
    border-color: #654633;
}

/* MAIN CONTENT */

.container {
    max-width: 1200px;
    margin: 35px auto 50px;
    padding: 0 25px;
}

.card {
    padding: 25px;
    background: #fffdf9;
    border: 1px solid #dfcbb7;
    border-radius: 16px;
    box-shadow: 0 4px 12px rgba(57, 39, 31, 0.06);
    overflow-x: auto;
}

.users-heading {
    display: flex;
    justify-content: space-between;
    align-items: center;
    gap: 15px;
    flex-wrap: wrap;
    margin-bottom: 20px;
}

.users-heading h2 {
    margin: 0 0 10px;
}

.users-heading p {
    margin: 0;
    color: #654633;
}

.add-user-btn {
    display: inline-block;
    background: #654633;
    color: white;
    padding: 13px 20px;
    border-radius: 30px;
    text-decoration: none;
    font-weight: bold;
    white-space: nowrap;
}

.add-user-btn:hover {
    background: #39271f;
}

/* TABLE */

table {
    width: 100%;
    border-collapse: collapse;
    min-width: 750px;
}

th,
td {
    padding: 14px 12px;
    border-bottom: 1px solid #eadfd2;
    text-align: left;
}

th {
    background: #f7f1e8;
    color: #39271f;
    white-space: nowrap;
}

tbody tr:hover {
    background: #fff8ed;
}

.role {
    font-weight: bold;
    text-transform: capitalize;
}

.empty {
    padding: 24px;
    text-align: center;
    color: #806c5d;
}

/* ACTION BUTTONS */

.action-form {
    margin: 0;
}

.delete-btn {
    padding: 9px 14px;
    border: none;
    border-radius: 8px;
    background: #a12d25;
    color: white;
    font-weight: bold;
    cursor: pointer;
}

.delete-btn:hover {
    background: #7d211b;
}

.reset-btn {
    display: inline-block;
    padding: 10px 16px;
    border-radius: 25px;
    background: #654633;
    color: white;
    text-decoration: none;
    font-weight: bold;
    white-space: nowrap;
}

.reset-btn:hover {
    background: #39271f;
}

.current-account {
    color: #806c5d;
    font-size: 13px;
    font-weight: bold;
}

/* FOOTER */

.site-footer {
    background: #39271f;
    color: #fffdf9;
    padding: 40px 7% 15px;
    margin-top: 50px;
}

.footer-content {
    display: flex;
    justify-content: space-between;
    align-items: flex-start;
    flex-wrap: wrap;
    gap: 35px;
    max-width: 1200px;
    margin: auto;
}

.footer-content h2 {
    margin: 0 0 10px;
    font-size: 22px;
}

.footer-content h3 {
    font-size: 15px;
    margin-bottom: 15px;
    color: #d7b998;
}

.footer-content p {
    color: #dfcbb7;
    font-size: 14px;
}

.social-icons {
    display: flex;
    gap: 12px;
}

.social-icons a {
    width: 40px;
    height: 40px;
    border-radius: 50%;
    background: #fffdf9;
    color: #654633;
    display: flex;
    justify-content: center;
    align-items: center;
    transition: 0.3s;
}

.social-icons a:hover {
    background: #d7b998;
    transform: translateY(-4px);
}

.social-icons svg {
    width: 21px;
    height: 21px;
    fill: currentColor;
    stroke: currentColor;
    stroke-width: 1.8;
}

.footer-bottom {
    border-top: 1px solid #765b48;
    text-align: center;
    margin-top: 30px;
    padding-top: 15px;
}

.footer-bottom p {
    font-size: 12px;
    color: #cbb8a7;
}

/* RESPONSIVE */

@media (max-width: 700px) {
    .main-header {
        padding: 18px 5%;
    }

    .header-actions {
        width: 100%;
    }

    .navbar {
        gap: 8px;
    }

    .navbar a {
        padding: 9px 13px;
        font-size: 13px;
    }

    .container {
        padding: 0 15px;
        margin-top: 25px;
    }

    .card {
        padding: 18px;
    }

    .users-heading {
        align-items: flex-start;
    }

    .footer-content {
        flex-direction: column;
        gap: 20px;
    }
}

@media (max-width: 450px) {
    .logo {
        width: 60px;
        height: 60px;
    }

    .brand-text h1 {
        font-size: 21px;
    }

    .role-badge,
    .pos-badge,
    .logout-btn {
        padding: 9px 13px;
        font-size: 12px;
    }
}
</style>
</head>

<body>

<!-- HEADER -->

<header class="main-header">

    <div class="brand">

        <img
            src="assets/images/logo.png"
            alt="Nook32 Coffee Logo"
            class="logo"
        >

        <div class="brand-text">
            <h1>NOOK32 COFFEE</h1>
            <p>Good coffee, cozy moments.</p>
        </div>

    </div>

    <div class="header-actions">

        <span class="role-badge">
            <?= e(ucfirst($userRole)) ?>
        </span>

        <a href="logout.php" class="logout-btn">
            Logout
        </a>

    </div>

</header>

<!-- NAVIGATION -->

<nav class="navbar">

    <a href="index.php">POS Menu</a>

    <a href="order_history.php">Order History</a>

    <a href="dashboard.php">Dashboard</a>

    <a href="inventory.php">Inventory</a>

    <a href="manage_users.php" class="active">Manage Users</a>

</nav>

<!-- MAIN CONTENT -->

<main class="container">

    <section class="card">

        <div class="users-heading">

            <div>
                <h2>Registered Users</h2>
                <p>View the accounts registered in your POS system.</p>
            </div>

            <a href="add_user.php" class="add-user-btn">
                + Add New User
            </a>

        </div>

        <table>

            <thead>
                <tr>
                    <th>ID</th>
                    <th>Full Name</th>
                    <th>Username</th>
                    <th>Role</th>
                    <th>Date Created</th>
                    <th>Action</th>
                    <th>Delete</th>
                </tr>
            </thead>

            <tbody>

            <?php if ($result && $result->num_rows > 0): ?>

                <?php while ($user = $result->fetch_assoc()): ?>

                    <tr>

                        <td><?= e($user['user_id']) ?></td>

                        <td><?= e($user['full_name']) ?></td>

                        <td><?= e($user['username']) ?></td>

                        <td class="role">
                            <?= e($user['role']) ?>
                        </td>

                        <td><?= e($user['created_at']) ?></td>

                        <td>

                            <?php if (
                                (int) $user['user_id'] !==
                                (int) $_SESSION['user_id']
                            ): ?>

                                <form
                                    class="action-form"
                                    method="POST"
                                    action="delete_user.php"
                                    onsubmit="return confirm('Are you sure you want to delete this account?');"
                                >

                                    <input
                                        type="hidden"
                                        name="csrf_token"
                                        value="<?= e($_SESSION['csrf_token'] ?? '') ?>"
                                    >

                                    <input
                                        type="hidden"
                                        name="user_id"
                                        value="<?= e($user['user_id']) ?>"
                                    >

                                    <button
                                        type="submit"
                                        class="delete-btn"
                                    >
                                        Delete
                                    </button>

                                </form>

                            <?php else: ?>

                                <span class="current-account">
                                    Current Account
                                </span>

                            <?php endif; ?>

                        </td>

                        <td>

                            <?php if (
                                (int) $user['user_id'] !==
                                (int) $_SESSION['user_id']
                            ): ?>

                                <a
                                    href="reset_password.php?id=<?= e($user['user_id']) ?>"
                                    class="reset-btn"
                                >
                                    Reset Password
                                </a>

                            <?php else: ?>

                                <span class="current-account">
                                    Current Account
                                </span>

                            <?php endif; ?>

                        </td>

                    </tr>

                <?php endwhile; ?>

            <?php else: ?>

                <tr>
                    <td colspan="7" class="empty">
                        No user accounts found.
                    </td>
                </tr>

            <?php endif; ?>

            </tbody>

        </table>

    </section>

</main>

<!-- FOOTER -->

<footer class="site-footer">

    <div class="footer-content">

        <div class="footer-brand">
            <h3>NOOK32 COFFEE ☕</h3>
            <p>Good coffee, cozy moments.</p>
        </div>

        <div class="footer-location">
            <h3>VISIT OUR SHOP</h3>
            <p>📍 No. 5 Mckinley St., Binmaley, Pangasinan</p>
        </div>

        <div class="footer-social">
            <h3>FOLLOW US</h3>

            <div class="social-icons">

                <a
                    href="https://facebook.com/nook32coffee"
                    target="_blank"
                    rel="noopener noreferrer"
                    aria-label="Facebook"
                >
                    <svg viewBox="0 0 24 24">
                        <path d="M13.5 21v-8h2.7l.4-3h-3.1V8.1c0-.9.3-1.5 1.6-1.5h1.7V3.9c-.3 0-1.3-.1-2.5-.1-2.5 0-4.2 1.5-4.2 4.3V10H7.5v3h2.6v8z"/>
                    </svg>
                </a>

                <a
                    href="https://instagram.com/nook32coffee"
                    target="_blank"
                    rel="noopener noreferrer"
                    aria-label="Instagram"
                >
                    <svg viewBox="0 0 24 24">
                        <rect x="3" y="3" width="18" height="18" rx="5"/>
                        <circle cx="12" cy="12" r="4"/>
                        <circle cx="17.5" cy="6.5" r="1" fill="currentColor" stroke="none"/>
                    </svg>
                </a>

                <a
                    href="https://tiktok.com/@nook32coffee"
                    target="_blank"
                    rel="noopener noreferrer"
                    aria-label="TikTok"
                >
                    <svg viewBox="0 0 24 24">
                        <path d="M14 3v11.2a3.2 3.2 0 1 1-3-3.2V8a6.2 6.2 0 1 0 6.2 6.2V9.1c1.3 1 2.8 1.5 4.3 1.6V7.5c-2.4-.2-4.1-1.8-4.5-4.5z"/>
                    </svg>
                </a>

            </div>
        </div>

    </div>

    <div class="footer-bottom">
        <p>© <?= date('Y') ?> Nook32 Coffee. All Rights Reserved.</p>
    </div>

</footer>

</body>
</html>
