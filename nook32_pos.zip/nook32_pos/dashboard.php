
<?php

require_once __DIR__ . '/auth.php';
requireRole('admin');

require_once __DIR__ . '/config/database.php';

date_default_timezone_set('Asia/Manila');

// Escape HTML output.
function e($value): string
{
    return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8');
}

// =========================
// DATE FILTER
// =========================

$period = $_GET['period'] ?? 'daily';

$allowedPeriods = ['daily', 'weekly', 'monthly', 'custom'];

if (!in_array($period, $allowedPeriods, true)) {
    $period = 'daily';
}

$todayDate = new DateTime('today');

$startDate = '';
$endDate = '';
$filterError = '';

if ($period === 'daily') {

    $startDate = $todayDate->format('Y-m-d');
    $endDate = $todayDate->format('Y-m-d');

} elseif ($period === 'weekly') {

    $weekStart = new DateTime('monday this week');
    $weekEnd = new DateTime('sunday this week');

    $startDate = $weekStart->format('Y-m-d');
    $endDate = $weekEnd->format('Y-m-d');

} elseif ($period === 'monthly') {

    $monthStart = new DateTime('first day of this month');
    $monthEnd = new DateTime('last day of this month');

    $startDate = $monthStart->format('Y-m-d');
    $endDate = $monthEnd->format('Y-m-d');

} elseif ($period === 'custom') {

    $requestedStart = $_GET['start_date'] ?? '';
    $requestedEnd = $_GET['end_date'] ?? '';

    $validStart = DateTime::createFromFormat('!Y-m-d', $requestedStart);
    $validEnd = DateTime::createFromFormat('!Y-m-d', $requestedEnd);

    if (
        !$validStart ||
        !$validEnd ||
        $validStart->format('Y-m-d') !== $requestedStart ||
        $validEnd->format('Y-m-d') !== $requestedEnd ||
        $requestedStart > $requestedEnd
    ) {

        $filterError = 'Please select a valid date range.';

        $startDate = $todayDate->format('Y-m-d');
        $endDate = $todayDate->format('Y-m-d');

    } else {

        $startDate = $requestedStart;
        $endDate = $requestedEnd;

    }
}

// Convert the end date into an exclusive date boundary.
$endExclusive = new DateTime($endDate);
$endExclusive->modify('+1 day');

$endDateExclusive = $endExclusive->format('Y-m-d');

// Period title.
if ($period === 'daily') {
    $periodTitle = 'Daily Sales';
} elseif ($period === 'weekly') {
    $periodTitle = 'Weekly Sales';
} elseif ($period === 'monthly') {
    $periodTitle = 'Monthly Sales';
} else {
    $periodTitle = 'Custom Sales Report';
}

// Display date range.
$displayStart = new DateTime($startDate);
$displayEnd = new DateTime($endDate);

if ($startDate === $endDate) {
    $displayDate = $displayStart->format('F d, Y');
} else {
    $displayDate =
        $displayStart->format('M d, Y') .
        ' - ' .
        $displayEnd->format('M d, Y');
}

// =========================
// SALES SUMMARY
// PAID ORDERS ONLY
// =========================

$todaySql = "SELECT
                COALESCE(SUM(total_amount), 0) AS sales,
                COUNT(*) AS orders,
                COALESCE(SUM(discount_amount), 0) AS total_discounts,

                COALESCE(SUM(
                    CASE
                        WHEN discount_type IN ('senior', 'pwd') THEN 1
                        ELSE 0
                    END
                ), 0) AS discounted_orders,

                COALESCE(SUM(
                    CASE
                        WHEN discount_type = 'senior' THEN 1
                        ELSE 0
                    END
                ), 0) AS senior_orders,

                COALESCE(SUM(
                    CASE
                        WHEN discount_type = 'pwd' THEN 1
                        ELSE 0
                    END
                ), 0) AS pwd_orders

             FROM orders

             WHERE payment_status = 'paid'
               AND order_date >= ?
               AND order_date < ?";

$todayStmt = $conn->prepare($todaySql);

if (!$todayStmt) {
    die('Sales summary query failed: ' . e($conn->error));
}

$todayStmt->bind_param('ss', $startDate, $endDateExclusive);
$todayStmt->execute();

$todayResult = $todayStmt->get_result();
$today = $todayResult->fetch_assoc();

$todayStmt->close();

// =========================
// PAYMENT STATUS SUMMARY
// =========================

$statusSql = "SELECT
                    payment_status,
                    COUNT(*) AS total_orders

               FROM orders

               WHERE order_date >= ?
                 AND order_date < ?

               GROUP BY payment_status";

$statusStmt = $conn->prepare($statusSql);

if (!$statusStmt) {
    die('Payment summary query failed: ' . e($conn->error));
}

$statusStmt->bind_param('ss', $startDate, $endDateExclusive);
$statusStmt->execute();

$statusResult = $statusStmt->get_result();

$paymentSummary = [
    'paid' => 0,
    'pending' => 0,
    'failed' => 0
];

while ($status = $statusResult->fetch_assoc()) {

    if (array_key_exists($status['payment_status'], $paymentSummary)) {

        $paymentSummary[$status['payment_status']] =
            (int)$status['total_orders'];

    }

}

$statusStmt->close();

// =========================
// TOP 5 BEST-SELLING PRODUCTS
// PAID ORDERS ONLY
// =========================

$bestSql = "SELECT
                oi.product_id,
                oi.product_name,
                SUM(oi.quantity) AS quantity_sold,
                SUM(oi.item_total) AS revenue

             FROM order_items oi

             INNER JOIN orders o
                 ON o.order_id = oi.order_id

             WHERE o.payment_status = 'paid'
               AND o.order_date >= ?
               AND o.order_date < ?

             GROUP BY oi.product_id, oi.product_name

             ORDER BY quantity_sold DESC, revenue DESC

             LIMIT 5";

$bestStmt = $conn->prepare($bestSql);

if (!$bestStmt) {
    die('Best-selling products query failed: ' . e($conn->error));
}

$bestStmt->bind_param('ss', $startDate, $endDateExclusive);
$bestStmt->execute();

$bestResult = $bestStmt->get_result();

// =========================
// PERIOD LABEL
// =========================

if ($period === 'daily') {
    $periodLabel = 'Daily';
} elseif ($period === 'weekly') {
    $periodLabel = 'Weekly';
} elseif ($period === 'monthly') {
    $periodLabel = 'Monthly';
} else {
    $periodLabel = 'Custom Date Range';
}

?>

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Nook32 Coffee | Sales Dashboard</title>

    <style>

        * {
            box-sizing: border-box;
        }

        body {
            margin: 0;
            font-family: Arial, sans-serif;
            background: #f7f1e8;
            color: #39271f;
        }

        header {
            background: #39271f;
            color: #fff8ed;
            padding: 24px 6%;
            display: flex;
            justify-content: space-between;
            align-items: center;
            gap: 15px;
            flex-wrap: wrap;
        }

        .brand {
            display: flex;
            align-items: center;
            gap: 14px;
        }

        .logo {
            width: 65px;
            height: 65px;
            object-fit: contain;
            mix-blend-mode: screen;
        }

        header h1 {
            margin: 0;
            font-size: 26px;
        }

        header p {
            color: #dfcbb7;
            margin-bottom: 0;
        }

        nav {
            display: flex;
            flex-wrap: wrap;
            align-items: center;
            gap: 10px;
        }

        nav a {
            color: #fff8ed;
            text-decoration: none;
            border: 1px solid #a98a70;
            border-radius: 9px;
            padding: 10px 14px;
        }

        nav a:hover,
        nav a.active {
            background: #654633;
        }

        .role-label {
            color: #dfcbb7;
            font-weight: bold;
            padding: 0 5px;
            border: none;
            background: transparent;
            cursor: default;
        }

        main {
            max-width: 1200px;
            margin: 35px auto;
            padding: 0 20px;
        }

        .dashboard-heading {
            text-align: center;
            margin-bottom: 28px;
        }

        .dashboard-heading h2 {
            margin: 0 0 18px;
        }

        .today-date {
            display: inline-block;
            background: #fffdf9;
            border: 1px solid #e8dbcd;
            border-radius: 16px;
            padding: 18px 30px;
            margin-bottom: 15px;
            box-shadow: 0 4px 14px rgba(57, 39, 31, 0.04);
        }

        .today-label {
            display: block;
            color: #806c5d;
            font-size: 12px;
            font-weight: bold;
            letter-spacing: 2px;
            margin-bottom: 7px;
        }

        .today-date h3 {
            margin: 0;
            font-size: 25px;
        }

        .today-date p {
            margin: 7px 0 0;
            color: #806c5d;
        }

        .subtitle {
            color: #806c5d;
            line-height: 1.6;
        }

        /* DATE FILTER */

        .filter-panel {
            background: #fffdf9;
            border: 1px solid #e8dbcd;
            border-radius: 16px;
            padding: 22px;
            margin: 25px 0;
            box-shadow: 0 4px 14px rgba(57, 39, 31, 0.04);
        }

        .filter-panel h3 {
            margin-top: 0;
        }

        .period-buttons {
            display: flex;
            gap: 10px;
            flex-wrap: wrap;
            margin-bottom: 20px;
        }

        .period-buttons button {
            border: 1px solid #a98a70;
            background: #fffdf9;
            color: #39271f;
            padding: 10px 18px;
            border-radius: 9px;
            cursor: pointer;
            font: inherit;
            font-weight: bold;
        }

        .period-buttons button:hover {
            background: #eee1d1;
        }

        .period-buttons button.active {
            background: #654633;
            color: #fff8ed;
            border-color: #654633;
        }

        .custom-dates {
            display: flex;
            flex-wrap: wrap;
            align-items: end;
            gap: 15px;
        }

        .date-group {
            display: flex;
            flex-direction: column;
            gap: 7px;
            flex: 1;
            min-width: 180px;
        }

        .date-group label {
            font-weight: bold;
            font-size: 14px;
        }

        .date-group input {
            width: 100%;
            padding: 11px 12px;
            border: 1px solid #dfcbb7;
            border-radius: 8px;
            background: #fffdf9;
            color: #39271f;
            font: inherit;
        }

        .filter-button {
            background: #654633;
            color: #fff8ed;
            border: none;
            border-radius: 8px;
            padding: 11px 18px;
            cursor: pointer;
            font: inherit;
            font-weight: bold;
        }

        .filter-button:hover {
            background: #39271f;
        }

        .filter-error {
            color: #842029;
            background: #f8d7da;
            padding: 12px;
            border-radius: 8px;
            margin-bottom: 15px;
        }

        .stats {
            display: grid;
            grid-template-columns: repeat(3, minmax(0, 1fr));
            gap: 18px;
            margin: 25px 0 35px;
        }

        .stat-card,
        .panel {
            background: #fffdf9;
            border: 1px solid #e8dbcd;
            border-radius: 16px;
            padding: 22px;
            box-shadow: 0 4px 14px rgba(57, 39, 31, 0.04);
        }

        .stat-card p {
            color: #806c5d;
            margin: 0 0 12px;
        }

        .stat-card h3 {
            font-size: 27px;
            margin: 0;
            overflow-wrap: anywhere;
        }

        .stat-card small {
            display: block;
            margin-top: 9px;
            color: #806c5d;
            line-height: 1.5;
        }

        .panel {
            margin-bottom: 25px;
        }

        .panel h3 {
            margin-top: 0;
        }

        .table-container {
            overflow-x: auto;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            min-width: 480px;
        }

        th,
        td {
            padding: 13px 10px;
            text-align: left;
            border-bottom: 1px solid #e8dbcd;
        }

        th {
            background: #eee1d1;
        }

        tr:last-child td {
            border-bottom: none;
        }

        .empty {
            padding: 18px;
            color: #806c5d;
            text-align: center;
        }

        .dashboard-links {
            display: flex;
            gap: 10px;
            flex-wrap: wrap;
            margin-top: 22px;
        }

        .dashboard-links a {
            display: inline-block;
            background: #654633;
            color: #fff8ed;
            text-decoration: none;
            border-radius: 9px;
            padding: 11px 15px;
        }

        .dashboard-links a:hover {
            background: #39271f;
        }

        footer {
            text-align: center;
            color: #806c5d;
            padding: 35px 15px;
        }

        @media (max-width: 900px) {

            .stats {
                grid-template-columns: repeat(2, minmax(0, 1fr));
            }

        }

        @media (max-width: 600px) {

            header {
                align-items: flex-start;
                flex-direction: column;
            }

            .stats {
                grid-template-columns: 1fr;
            }

            .stat-card h3 {
                font-size: 24px;
            }

            .today-date h3 {
                font-size: 22px;
            }

            .custom-dates {
                flex-direction: column;
                align-items: stretch;
            }

        }

        /* FOOTER */

.site-footer {
    background: #39271f;
    color: #fffdf9;
    padding: 40px 7% 15px;
    margin-top: 50px;
}

.footer-content {
    display: flex;
    justify-content: space-between;
    align-items: flex-start;
    flex-wrap: wrap;
    gap: 35px;
    max-width: 1200px;
    margin: auto;
}

.footer-content h2 {
    margin: 0 0 10px;
    font-size: 22px;
}

.footer-content h3 {
    font-size: 15px;
    margin-bottom: 15px;
    color: #d7b998;
}

.footer-content p {
    color: #dfcbb7;
    font-size: 14px;
}

.social-icons {
    display: flex;
    gap: 12px;
}

.social-icons a {
    width: 40px;
    height: 40px;
    border-radius: 50%;
    background: #fffdf9;
    color: #654633;
    display: flex;
    justify-content: center;
    align-items: center;
    transition: 0.3s;
}

.social-icons a:hover {
    background: #d7b998;
    transform: translateY(-4px);
}

.social-icons svg {
    width: 21px;
    height: 21px;
    fill: currentColor;
    stroke: currentColor;
    stroke-width: 1.8;
}

.footer-bottom {
    border-top: 1px solid #765b48;
    text-align: center;
    margin-top: 30px;
    padding-top: 15px;
}

.footer-bottom p {
    font-size: 12px;
    color: #cbb8a7;
}

    </style>

</head>

<body>

<header>

    <div class="brand">

        <img src="assets/images/logo.png"
             alt="Nook32 Coffee Logo"
             class="logo">

        <div>

            <h1>NOOK32 COFFEE</h1>

            <p>Sales and Performance Overview</p>

        </div>

    </div>

    <nav>

        <span class="role-label">Admin</span>

        <a href="index.php">
            POS Menu

        <a href="order_history.php">
            Order History
        </a>

        <a href="dashboard.php" class="active">
            Sales Dashboard
        </a>

        <a href="logout.php">
            Logout
        </a>

    </nav>

</header>

<main>

    <div class="dashboard-heading">

        <h2>Sales Dashboard</h2>

        <div class="today-date">

            <span class="today-label">
                <?= e(strtoupper($periodLabel)) ?>
            </span>

            <h3>
                <?= e($displayDate) ?>
            </h3>

            <?php if ($period === 'daily'): ?>

                <p><?= e($displayStart->format('l')) ?></p>

            <?php elseif ($period === 'weekly'): ?>

                <p>Monday - Sunday</p>

            <?php elseif ($period === 'monthly'): ?>

                <p><?= e($displayStart->format('F Y')) ?></p>

            <?php else: ?>

                <p>Selected date range</p>

            <?php endif; ?>

        </div>

        <p class="subtitle">
            <?= e($periodTitle) ?> summary of sales and payment activity.
            Only confirmed paid orders are included in sales totals.
        </p>

    </div>

    <!-- DATE FILTER -->

    <section class="filter-panel">

        <h3>Sales Period</h3>

        <?php if ($filterError !== ''): ?>

            <div class="filter-error">
                <?= e($filterError) ?>
            </div>

        <?php endif; ?>

        <form method="GET" action="dashboard.php" id="salesFilter">

            <div class="period-buttons">

                <button type="submit"
                        name="period"
                        value="daily"
                        class="<?= $period === 'daily' ? 'active' : '' ?>">

                    Daily

                </button>

                <button type="submit"
                        name="period"
                        value="weekly"
                        class="<?= $period === 'weekly' ? 'active' : '' ?>">

                    Weekly

                </button>

                <button type="submit"
                        name="period"
                        value="monthly"
                        class="<?= $period === 'monthly' ? 'active' : '' ?>">

                    Monthly

                </button>

                <button type="button"
                        id="customToggle"
                        class="<?= $period === 'custom' ? 'active' : '' ?>">

                    Custom Date

                </button>

            </div>

            <input type="hidden"
                   name="period"
                   id="periodInput"
                   value="<?= e($period) ?>">

            <div class="custom-dates"
                 id="customDates"
                 style="<?= $period === 'custom' ? '' : 'display:none;' ?>">

                <div class="date-group">

                    <label for="start_date">
                        Start Date
                    </label>

                    <input type="date"
                           name="start_date"
                           id="start_date"
                           value="<?= e($startDate) ?>"
                           required>

                </div>

                <div class="date-group">

                    <label for="end_date">
                        End Date
                    </label>

                    <input type="date"
                           name="end_date"
                           id="end_date"
                           value="<?= e($endDate) ?>"
                           required>

                </div>

                <button type="submit"
                        class="filter-button"
                        id="applyCustom">

                    Apply Date Range

                </button>

            </div>

        </form>

    </section>

    <!-- SALES STATISTICS -->

    <section class="stats">

        <article class="stat-card">

            <p>Total Sales</p>

            <h3>
                ₱<?= number_format((float)$today['sales'], 2) ?>
            </h3>

        </article>

        <article class="stat-card">

            <p>Paid Orders</p>

            <h3>
                <?= number_format((int)$today['orders']) ?>
            </h3>

        </article>

        <article class="stat-card">

            <p>Pending Payments</p>

            <h3>
                <?= number_format($paymentSummary['pending']) ?>
            </h3>

        </article>

        <article class="stat-card">

            <p>Failed Payments</p>

            <h3>
                <?= number_format($paymentSummary['failed']) ?>
            </h3>

        </article>

        <article class="stat-card">

            <p>Discounted Orders</p>

            <h3>
                <?= number_format((int)$today['discounted_orders']) ?>
            </h3>

            <small>

                Senior:
                <?= number_format((int)$today['senior_orders']) ?>

                <br>

                PWD:
                <?= number_format((int)$today['pwd_orders']) ?>

            </small>

        </article>

        <article class="stat-card">

            <p>Total Discounts Given</p>

            <h3>
                ₱<?= number_format((float)$today['total_discounts'], 2) ?>
            </h3>

        </article>

    </section>

    <!-- TOP SELLING PRODUCTS -->

    <section class="panel">

        <h3>
            <?= e($periodLabel) ?> Top-Selling Products
        </h3>

        <p class="subtitle">

            The five best-selling products from confirmed paid orders
            for <?= e($displayDate) ?>, including regular,
            Senior Citizen, and PWD discounted purchases.

        </p>

        <?php if ($bestResult && $bestResult->num_rows > 0): ?>

            <div class="table-container">

                <table>

                    <thead>

                        <tr>
                            <th>Rank</th>
                            <th>Product</th>
                            <th>Quantity Sold</th>
                            <th>Item Revenue (Before Discounts)</th>
                        </tr>

                    </thead>

                    <tbody>

                        <?php $rank = 1; ?>

                        <?php while ($product = $bestResult->fetch_assoc()): ?>

                            <tr>

                                <td>
                                    <?= $rank++ ?>
                                </td>

                                <td>
                                    <?= e($product['product_name']) ?>
                                </td>

                                <td>
                                    <?= number_format((int)$product['quantity_sold']) ?>
                                </td>

                                <td>
                                    ₱<?= number_format((float)$product['revenue'], 2) ?>
                                </td>

                            </tr>

                        <?php endwhile; ?>

                    </tbody>

                </table>

            </div>

        <?php else: ?>

            <p class="empty">
                No paid orders are available for this sales period yet.
            </p>

        <?php endif; ?>

    </section>

    </div>

</main>

<!-- FOOTER -->

<footer class="site-footer">

    <div class="footer-content">

        <div class="footer-brand">
            <h3>NOOK32 COFFEE ☕</h3>
            <p>Good coffee, cozy moments.</p>
        </div>

        <div class="footer-location">
            <h3>VISIT OUR SHOP</h3>
            <p>📍 No. 5 Mckinley St., Binmaley, Pangasinan</p>
        </div>

        <div class="footer-social">

            <h3>FOLLOW US</h3>

            <div class="social-icons">

                <!-- FACEBOOK -->

                <a
                    href="https://facebook.com/nook32coffee"
                    target="_blank"
                    rel="noopener noreferrer"
                    aria-label="Facebook"
                >
                    <svg viewBox="0 0 24 24">
                        <path d="M13.5 21v-8h2.7l.4-3h-3.1V8.1c0-.9.3-1.5 1.6-1.5h1.7V3.9c-.3 0-1.3-.1-2.5-.1-2.5 0-4.2 1.5-4.2 4.3V10H7.5v3h2.6v8z"/>
                    </svg>
                </a>

                <!-- INSTAGRAM -->

                <a
                    href="https://instagram.com/nook32coffee"
                    target="_blank"
                    rel="noopener noreferrer"
                    aria-label="Instagram"
                >
                    <svg viewBox="0 0 24 24">
                        <rect x="3" y="3" width="18" height="18" rx="5"/>
                        <circle cx="12" cy="12" r="4"/>
                        <circle cx="17.5" cy="6.5" r="1" fill="currentColor" stroke="none"/>
                    </svg>
                </a>

                <!-- TIKTOK -->

                <a
                    href="https://tiktok.com/@nook32coffee"
                    target="_blank"
                    rel="noopener noreferrer"
                    aria-label="TikTok"
                >
                    <svg viewBox="0 0 24 24">
                        <path d="M14 3v11.2a3.2 3.2 0 1 1-3-3.2V8a6.2 6.2 0 1 0 6.2 6.2V9.1c1.3 1 2.8 1.5 4.3 1.6V7.5c-2.4-.2-4.1-1.8-4.5-4.5z"/>
                    </svg>
                </a>

            </div>

        </div>

    </div>

    <div class="footer-bottom">
        <p>
            © <?= date('Y') ?> Nook32 Coffee. All Rights Reserved.
        </p>
    </div>

</footer>

<script>

    const customToggle = document.getElementById('customToggle');
    const customDates = document.getElementById('customDates');
    const periodInput = document.getElementById('periodInput');
    const startDateInput = document.getElementById('start_date');
    const endDateInput = document.getElementById('end_date');

    customToggle.addEventListener('click', function () {

        customDates.style.display = 'flex';
        customToggle.classList.add('active');
        periodInput.value = 'custom';

    });

    startDateInput.addEventListener('change', function () {

        endDateInput.min = startDateInput.value;

    });

    endDateInput.addEventListener('change', function () {

        startDateInput.max = endDateInput.value;

    });

    document.getElementById('applyCustom').addEventListener('click', function () {

        periodInput.value = 'custom';

    });

</script>

</body>

</html>
