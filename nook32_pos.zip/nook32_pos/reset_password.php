<?php
require_once __DIR__ . '/auth.php';
requireRole('admin');

require_once __DIR__ . '/config/database.php';

$message = '';
$messageType = '';

$userId = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);

if (!$userId || $userId < 1) {
    http_response_code(400);
    exit('Invalid user ID.');
}

// Fetch the selected user
$stmt = $conn->prepare(
    'SELECT user_id, full_name, username, role
     FROM users
     WHERE user_id = ?'
);
$stmt->bind_param('i', $userId);
$stmt->execute();

$user = $stmt->get_result()->fetch_assoc();
$stmt->close();

if (!$user) {
    http_response_code(404);
    exit('User account not found.');
}

// Prevent the admin from resetting their own password here
if ((int)$user['user_id'] === (int)$_SESSION['user_id']) {
    exit('You cannot reset your own password from this page.');
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (
        !isset($_POST['csrf_token'], $_SESSION['csrf_token']) ||
        !hash_equals($_SESSION['csrf_token'], $_POST['csrf_token'])
    ) {
        http_response_code(403);
        exit('Invalid security token. Please return and try again.');
    }

    $newPassword = $_POST['new_password'] ?? '';
    $confirmPassword = $_POST['confirm_password'] ?? '';

    if (strlen($newPassword) < 8) {
        $message = 'Password must be at least 8 characters long.';
        $messageType = 'error';
    } elseif ($newPassword !== $confirmPassword) {
        $message = 'The passwords do not match.';
        $messageType = 'error';
    } else {
        $hashedPassword = password_hash(
            $newPassword,
            PASSWORD_DEFAULT
        );

        $update = $conn->prepare(
            'UPDATE users SET password = ? WHERE user_id = ?'
        );
        $update->bind_param('si', $hashedPassword, $userId);

        if ($update->execute()) {
            $message = 'Password reset successfully.';
            $messageType = 'success';
        } else {
            $message = 'Unable to reset the password.';
            $messageType = 'error';
        }

        $update->close();
    }
}

function e($value): string
{
    return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8');
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reset Password | Nook32 Coffee</title>

    <style>
        * {
            box-sizing: border-box;
        }

        body {
            margin: 0;
            padding: 30px 16px;
            font-family: Arial, sans-serif;
            background: #f7f1e8;
            color: #39271f;
        }

        .container {
            max-width: 600px;
            margin: auto;
        }

        .card {
            background: #fffdf9;
            border: 1px solid #dfcbb7;
            border-radius: 16px;
            padding: 25px;
        }

        label {
            display: block;
            margin: 16px 0 7px;
            font-weight: bold;
        }

        input {
            width: 100%;
            padding: 12px;
            border: 1px solid #d8c3b0;
            border-radius: 8px;
            font-size: 15px;
        }

        button, .back {
            display: inline-block;
            padding: 12px 18px;
            border: none;
            border-radius: 24px;
            background: #654633;
            color: white;
            text-decoration: none;
            font-weight: bold;
            cursor: pointer;
        }

        button {
            width: 100%;
            margin-top: 22px;
        }

        .message {
            padding: 12px;
            border-radius: 8px;
            margin: 15px 0;
        }

        .success {
            background: #e5f4e8;
            color: #245c32;
        }

        .error {
            background: #fbe8e5;
            color: #8b2e22;
        }

        .note {
            color: #765f50;
            font-size: 13px;
        }
    </style>
</head>
<body>
<div class="container">
    <p><a class="back" href="manage_users.php">Back to Manage Users</a></p>

    <div class="card">
        <h1>Reset User Password</h1>

        <p>
            Account:
            <strong><?= e($user['full_name']) ?></strong>
            (<?= e($user['username']) ?>)
        </p>

        <p>Role: <?= e($user['role']) ?></p>

        <?php if ($message !== ''): ?>
            <div class="message <?= e($messageType) ?>">
                <?= e($message) ?>
            </div>
        <?php endif; ?>

        <form method="POST">
            <input
                type="hidden"
                name="csrf_token"
                value="<?= e($_SESSION['csrf_token']) ?>"
            >

            <label for="new_password">New Password</label>
            <input
                type="password"
                id="new_password"
                name="new_password"
                minlength="8"
                required
            >

            <label for="confirm_password">Confirm New Password</label>
            <input
                type="password"
                id="confirm_password"
                name="confirm_password"
                minlength="8"
                required
            >

            <p class="note">
                Use at least 8 characters. Give the new password privately to the account holder.
            </p>

            <button type="submit">Reset Password</button>
        </form>
    </div>
</div>
</body>
</html>
