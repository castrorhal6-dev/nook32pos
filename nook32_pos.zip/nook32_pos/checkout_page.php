
<?php
session_start();

require_once __DIR__ . '/auth.php';
requireLogin();
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Nook32 Coffee | Checkout</title>

<style>
* {
    box-sizing: border-box;
}

body {
    margin: 0;
    font-family: Arial, sans-serif;
    background: #f7f1e8;
    color: #39271f;
}

header {
    position: sticky;
    top: 0;
    z-index: 100;
    background: #39271f;
    color: #fffdf9;
    padding: 22px 6%;
    box-shadow: 0 3px 12px rgba(57,39,31,.15);
}

header h1 {
    margin: 0;
}

header p {
    color: #dfcbb7;
    margin-bottom: 0;
}

main {
    max-width: 850px;
    margin: 35px auto;
    padding: 0 20px;
}

.back-link {
    display: inline-block;
    margin-bottom: 20px;
    color: #654633;
    text-decoration: none;
    font-weight: bold;
}

.back-link:hover {
    text-decoration: underline;
}

.checkout-card {
    background: #fffdf9;
    border: 1px solid #e8dbcd;
    border-radius: 16px;
    padding: 25px;
    margin-bottom: 20px;
}

.checkout-card h2 {
    margin-top: 0;
}

.order-item {
    display: flex;
    justify-content: space-between;
    gap: 15px;
    padding: 15px 0;
    border-bottom: 1px solid #e8dbcd;
}

.order-item small {
    display: block;
    color: #806c5d;
    margin-top: 5px;
}

.total-line {
    display: flex;
    justify-content: space-between;
    gap: 10px;
    margin-top: 18px;
    font-size: 18px;
    font-weight: bold;
}

.subtotal-line {
    font-size: 16px;
    font-weight: normal;
}

.discount-line {
    color: #28643c;
}

.final-total {
    font-size: 22px;
    border-top: 1px solid #e8dbcd;
    padding-top: 15px;
}

.discount-section {
    margin-top: 25px;
    padding: 18px;
    background: #f7f1e8;
    border: 1px solid #e8dbcd;
    border-radius: 12px;
}

.discount-section h3 {
    margin-top: 0;
    margin-bottom: 5px;
}

.discount-section p {
    color: #806c5d;
    font-size: 13px;
    line-height: 1.5;
}

.discount-section label {
    margin-top: 15px;
}

.discount-note {
    display: block;
    color: #806c5d;
    margin-top: 7px;
    font-size: 13px;
    line-height: 1.5;
}

label {
    display: block;
    font-weight: bold;
    margin: 18px 0 8px;
}

input, select {
    width: 100%;
    padding: 13px;
    border: 1px solid #d8c6b4;
    border-radius: 9px;
    background: #fffdf9;
    font-size: 15px;
    color: #39271f;
}

input:focus, select:focus {
    outline: 2px solid #b99a79;
    border-color: #654633;
}

.help {
    display: block;
    color: #806c5d;
    margin-top: 7px;
    font-size: 13px;
}

.change-preview {
    background: #f3e9dd;
    border-radius: 9px;
    padding: 13px;
    font-weight: bold;
}

.confirm-button {
    width: 100%;
    margin-top: 22px;
    padding: 15px;
    border: none;
    border-radius: 30px;
    background: #654633;
    color: white;
    font-size: 16px;
    font-weight: bold;
    cursor: pointer;
}

.confirm-button:hover {
    background: #493021;
}

.confirm-button:disabled {
    opacity: .6;
    cursor: not-allowed;
}

.message {
    margin-top: 15px;
    line-height: 1.6;
    overflow-wrap: anywhere;
}

.error {
    color: #a12d25;
}

.success {
    color: #28643c;
}

.empty {
    text-align: center;
    padding: 25px;
    color: #806c5d;
}

/* FOOTER */

.site-footer {
    background: #39271f;
    color: #fffdf9;
    padding: 40px 7% 15px;
    margin-top: 50px;
}

.footer-content {
    display: flex;
    justify-content: space-between;
    align-items: flex-start;
    flex-wrap: wrap;
    gap: 35px;
    max-width: 1200px;
    margin: auto;
}

.footer-content h2 {
    margin: 0 0 10px;
    font-size: 22px;
}

.footer-content h3 {
    font-size: 15px;
    margin-bottom: 15px;
    color: #d7b998;
}

.footer-content p {
    color: #dfcbb7;
    font-size: 14px;
}

.social-icons {
    display: flex;
    gap: 12px;
}

.social-icons a {
    width: 40px;
    height: 40px;
    border-radius: 50%;
    background: #fffdf9;
    color: #654633;
    display: flex;
    justify-content: center;
    align-items: center;
    transition: 0.3s;
}

.social-icons a:hover {
    background: #d7b998;
    transform: translateY(-4px);
}

.social-icons svg {
    width: 21px;
    height: 21px;
    fill: currentColor;
    stroke: currentColor;
    stroke-width: 1.8;
}

.footer-bottom {
    border-top: 1px solid #765b48;
    text-align: center;
    margin-top: 30px;
    padding-top: 15px;
}

.footer-bottom p {
    font-size: 12px;
    color: #cbb8a7;
}

@media (max-width: 600px) {
    header {
        padding: 18px 5%;
    }

    main {
        margin-top: 25px;
    }

    .checkout-card {
        padding: 18px;
    }

    .footer-content {
        flex-direction: column;
        gap: 20px;
    }

    .order-item {
        gap: 8px;
    }
}
</style>
</head>

<body>

<header>
    <h1>NOOK32 COFFEE</h1>
    <p>Good coffee, cozy moments.</p>
</header>

<main>

    <a href="index.php" class="back-link">
        ← Back to Menu
    </a>

    <h2>Checkout</h2>
    <p>Review your order before confirming payment.</p>

    <!-- ORDER SUMMARY -->
    <section class="checkout-card">

        <h2>Your Order</h2>

        <div id="orderItems"></div>

        <div class="total-line subtotal-line">
            <span>Subtotal</span>
            <span id="subtotal">₱0.00</span>
        </div>

        <!-- DISCOUNT -->
        <div class="discount-section">

            <h3>Customer Discount</h3>
            <p>Select the applicable discount if the customer is eligible.</p>

            <label for="discountType">Discount Type</label>
            <select id="discountType">
                <option value="none">No Discount</option>
                <option value="senior">Senior Citizen (20%)</option>
                <option value="pwd">PWD (20%)</option>
            </select>

            <div id="discountIdField" style="display:none;">

                <label for="discountId">
                    Senior Citizen / PWD ID Number
                </label>

                <input
                    type="text"
                    id="discountId"
                    maxlength="150"
                    placeholder="Enter ID number"
                >

                <small class="discount-note">
                    Please verify the customer's valid ID before applying the discount.
                </small>

            </div>

            <div class="total-line discount-line">
                <span>Discount</span>
                <span id="discountAmount">−₱0.00</span>
            </div>

        </div>

        <div class="total-line final-total">
            <span>Total</span>
            <span id="total">₱0.00</span>
        </div>

    </section>

    <!-- PAYMENT DETAILS -->
    <section class="checkout-card">

        <h2>Payment Details</h2>

        <label for="paymentMethod">Payment Method</label>

        <select id="paymentMethod">
            <option value="cash">Cash</option>
            <option value="qr">QR Payment</option>
        </select>

        <!-- CASH -->
        <div id="cashFields">

            <label for="cashReceived">Cash Received (₱)</label>

            <input
                type="number"
                id="cashReceived"
                min="0"
                step="0.01"
                placeholder="Enter amount received"
            >

            <small class="help">
                Enter the cash physically received from the customer.
            </small>

            <p class="change-preview" id="changePreview">
                Change: ₱0.00
            </p>

        </div>

        <!-- QR -->
        <div id="qrFields" style="display:none;">

            <label for="paymentReference">
                QR Payment Reference Number
            </label>

            <input
                type="text"
                id="paymentReference"
                maxlength="150"
                placeholder="Enter payment reference"
            >

            <small class="help">
                QR payments remain pending until verified.
            </small>

        </div>

        <button
            type="button"
            class="confirm-button"
            id="confirmButton"
            onclick="checkoutOrder()"
        >
            Confirm Order
        </button>

        <p id="message" class="message" role="status"></p>

    </section>

</main>

<footer class="site-footer">

    <div class="footer-content">

        <div class="footer-brand">
            <h2>NOOK32 COFFEE ☕</h2>
            <p>Good coffee, cozy moments.</p>
        </div>

        <div class="footer-location">
            <h3>VISIT OUR SHOP</h3>
            <p>📍 No. 5 Mckinley St., Binmaley, Pangasinan</p>
        </div>

        <div class="footer-social">
            <h3>FOLLOW US</h3>

            <div class="social-icons">

                <!-- Facebook -->
                <a href="https://facebook.com/nook32coffee"
                   target="_blank"
                   rel="noopener noreferrer"
                   aria-label="Facebook">
                    <svg viewBox="0 0 24 24">
                        <path d="M13.5 21v-8h2.7l.4-3h-3.1V8.1c0-.9.3-1.5 1.6-1.5h1.7V3.9c-.3 0-1.3-.1-2.5-.1-2.5 0-4.2 1.5-4.2 4.3V10H7.5v3h2.6v8z"/>
                    </svg>
                </a>

                <!-- Instagram -->
                <a href="https://instagram.com/nook32coffee"
                   target="_blank"
                   rel="noopener noreferrer"
                   aria-label="Instagram">
                    <svg viewBox="0 0 24 24">
                        <rect x="3" y="3" width="18" height="18" rx="5"/>
                        <circle cx="12" cy="12" r="4"/>
                        <circle cx="17.5" cy="6.5" r="1" fill="currentColor" stroke="none"/>
                    </svg>
                </a>

                <!-- TikTok -->
                <a href="https://tiktok.com/@nook32coffee"
                   target="_blank"
                   rel="noopener noreferrer"
                   aria-label="TikTok">
                    <svg viewBox="0 0 24 24">
                        <path d="M14 3v11.2a3.2 3.2 0 1 1-3-3.2V8a6.2 6.2 0 1 a0 6.2 6.2 6.2 0 0 0 6.2-6.2V9.1c1.3 1 2.8 1.5 4.3 1.6V7.5c-2.4-.2-4.1-1.8-4.5-4.5z"/>
                    </svg>
                </a>

            </div>
        </div>

    </div>

    <div class="footer-bottom">
        <p>© <?= date('Y') ?> Nook32 Coffee. All Rights Reserved.</p>
    </div>

</footer>

<script>
let cart = [];

try {
    cart = JSON.parse(sessionStorage.getItem('nook32_cart')) || [];
} catch (error) {
    cart = [];
}

const paymentMethod = document.getElementById('paymentMethod');
const cashReceived = document.getElementById('cashReceived');
const paymentReference = document.getElementById('paymentReference');

const cashFields = document.getElementById('cashFields');
const qrFields = document.getElementById('qrFields');

const changePreview = document.getElementById('changePreview');
const confirmButton = document.getElementById('confirmButton');
const message = document.getElementById('message');

const discountType = document.getElementById('discountType');
const discountId = document.getElementById('discountId');
const discountIdField = document.getElementById('discountIdField');
const discountAmountDisplay = document.getElementById('discountAmount');

// Original subtotal before discount.
function getSubtotal() {
    return Math.round(
        cart.reduce((sum, item) => {
            return sum + (Number(item.price) * Number(item.quantity));
        }, 0) * 100
    ) / 100;
}

// Calculates the discounted total using the same method
// as checkout.php: discount per unit, rounded to 2 decimals.
function getDiscountedTotal() {
    if (discountType.value === 'none') {
        return getSubtotal();
    }

    return Math.round(
        cart.reduce((sum, item) => {
            const originalUnitPrice = Number(item.price);
            const quantity = Number(item.quantity);

            const discountedUnitPrice =
                Math.round(originalUnitPrice * 0.80 * 100) / 100;

            return sum + (discountedUnitPrice * quantity);
        }, 0) * 100
    ) / 100;
}

function getDiscountAmount() {
    return Math.round((getSubtotal() - getDiscountedTotal()) * 100) / 100;
}

function getTotal() {
    return getDiscountedTotal();
}

function renderOrder() {
    const container = document.getElementById('orderItems');

    container.replaceChildren();

    if (cart.length === 0) {
        container.innerHTML =
            '<p class="empty">Your cart is empty. Please return to the menu.</p>';

        document.getElementById('subtotal').textContent = '₱0.00';
        discountAmountDisplay.textContent = '−₱0.00';
        document.getElementById('total').textContent = '₱0.00';

        confirmButton.disabled = true;
        updateChange();
        return;
    }

    confirmButton.disabled = false;

    cart.forEach(item => {
        const row = document.createElement('div');
        row.className = 'order-item';

        const info = document.createElement('div');

        const name = document.createElement('strong');
        name.textContent = item.name;

        const details = document.createElement('small');
        details.textContent =
            'Quantity: ' + item.quantity +
            ' × ₱' + Number(item.price).toFixed(2);

        info.append(name, details);

        const amount = document.createElement('strong');
        amount.textContent =
            '₱' + (Number(item.price) * Number(item.quantity)).toFixed(2);

        row.append(info, amount);
        container.appendChild(row);
    });

    document.getElementById('subtotal').textContent =
        '₱' + getSubtotal().toFixed(2);

    discountAmountDisplay.textContent =
        '−₱' + getDiscountAmount().toFixed(2);

    document.getElementById('total').textContent =
        '₱' + getTotal().toFixed(2);

    updatePaymentFields();
}

function updatePaymentFields() {
    const isCash = paymentMethod.value === 'cash';

    cashFields.style.display = isCash ? 'block' : 'none';
    qrFields.style.display = isCash ? 'none' : 'block';

    cashReceived.required = isCash;
    paymentReference.required = !isCash;

    confirmButton.textContent = isCash
        ? 'Confirm Cash Payment & Save Order'
        : 'Save QR Order as Pending';

    updateChange();
}

function updateChange() {
    const total = getTotal();
    const received = Number(cashReceived.value);

    if (
        cart.length === 0 ||
        cashReceived.value === '' ||
        !Number.isFinite(received) ||
        received < total
    ) {
        changePreview.textContent =
            'Enter enough cash to cover ₱' + total.toFixed(2);
        return;
    }

    changePreview.textContent =
        'Change: ₱' + (received - total).toFixed(2);
}

function updateDiscountFields() {
    const hasDiscount = discountType.value !== 'none';

    discountIdField.style.display = hasDiscount ? 'block' : 'none';
    discountId.required = hasDiscount;

    if (!hasDiscount) {
        discountId.value = '';
    }

    renderOrder();
}

async function checkoutOrder() {
    if (cart.length === 0) {
        message.className = 'message error';
        message.textContent = 'Your cart is empty.';
        return;
    }

    const method = paymentMethod.value;
    const total = getTotal();
    const selectedDiscount = discountType.value;
    const enteredDiscountId = discountId.value.trim();

    // Validate discount ID on the checkout screen.
    if (selectedDiscount !== 'none' && enteredDiscountId === '') {
        message.className = 'message error';
        message.textContent =
            'Please enter the Senior Citizen or PWD ID number.';
        discountId.focus();
        return;
    }

    // Validate cash payment.
    if (method === 'cash') {
        const received = Number(cashReceived.value);

        if (
            cashReceived.value === '' ||
            !Number.isFinite(received) ||
            received < total
        ) {
            message.className = 'message error';
            message.textContent =
                'Please enter enough cash to cover the discounted order total.';
            cashReceived.focus();
            return;
        }

        if (!confirm(
            'Confirm that ₱' + received.toFixed(2) +
            ' cash has been received?\n\n' +
            'Order total: ₱' + total.toFixed(2) +
            (selectedDiscount !== 'none'
                ? '\nDiscount: ₱' + getDiscountAmount().toFixed(2)
                : '')
        )) {
            return;
        }

    } else if (!paymentReference.value.trim()) {
        message.className = 'message error';
        message.textContent =
            'Please enter the QR payment reference number.';
        paymentReference.focus();
        return;
    }

    confirmButton.disabled = true;
    message.className = 'message';
    message.textContent = 'Processing your order...';

    try {
        const response = await fetch('checkout.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },

            body: JSON.stringify({
                items: cart.map(item => ({
                    id: item.id,
                    quantity: item.quantity
                })),

                payment_method: method,

                payment_reference: method === 'qr'
                    ? paymentReference.value.trim()
                    : null,

                cash_received: method === 'cash'
                    ? cashReceived.value
                    : null,

                discount_type: selectedDiscount,

                discount_id: selectedDiscount !== 'none'
                    ? enteredDiscountId
                    : null
            })
        });

        const result = await response.json();

        if (!response.ok || !result.success) {
            throw new Error(
                result.message || 'Unable to process order.'
            );
        }

        sessionStorage.removeItem('nook32_cart');
        cart = [];

        if (result.payment_status === 'paid') {
            message.className = 'message success';

            message.textContent =
                'Order #' + result.order_id +
                ' successfully paid! Total: ₱' + result.total +
                '. Change: ₱' + result.change;
        } else {
            message.className = 'message success';

            message.textContent =
                'Order #' + result.order_id +
                ' saved successfully. QR payment is pending verification. ' +
                'Total: ₱' + result.total;
        }

        renderOrder();

        paymentMethod.disabled = true;
        cashReceived.disabled = true;
        paymentReference.disabled = true;
        discountType.disabled = true;
        discountId.disabled = true;

    } catch (error) {
        message.className = 'message error';
        message.textContent = error.message;
        confirmButton.disabled = false;
    }
}

paymentMethod.addEventListener('change', updatePaymentFields);
cashReceived.addEventListener('input', updateChange);
discountType.addEventListener('change', updateDiscountFields);
discountId.addEventListener('input', updateChange);

renderOrder();
updateDiscountFields();
</script>

</body>
</html>
