<?php
require_once __DIR__ . '/config/database.php';

$fullName = 'Nook32 Cashier';
$username = 'cashier1';
$plainPassword = 'Cashier123!';

$hashedPassword = password_hash($plainPassword, PASSWORD_DEFAULT);

$stmt = $conn->prepare(
    "INSERT INTO users (full_name, username, password, role)
     VALUES (?, ?, ?, 'cashier')"
);

$stmt->bind_param(
    "sss",
    $fullName,
    $username,
    $hashedPassword
);

try {
    $stmt->execute();
    echo "Cashier account created successfully!";
} catch (mysqli_sql_exception $e) {
    if ($e->getCode() === 1062) {
        echo "The username already exists. Choose another username.";
    } else {
        error_log($e->getMessage());
        http_response_code(500);
        echo "Unable to create the account. Check the PHP error log.";
    }
}

$stmt->close();
?>
