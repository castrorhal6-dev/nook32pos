
<?php

require_once __DIR__ . '/auth.php';
requireRole('admin');

require_once __DIR__ . '/classes/Database.php';
require_once __DIR__ . '/classes/InventoryManager.php';

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

$csrfToken = $_SESSION['csrf_token'];

$database = new Database();
$conn = $database->getConnection();
$inventory = new InventoryManager($database);

$message = '';
$messageType = 'success';

function e($value): string
{
    return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8');
}

function goInventory(string $msg): void
{
    header('Location: inventory.php?message=' . urlencode($msg));
    exit;
}

/* =========================
   POST ACTIONS
========================= */

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $action = $_POST['action'] ?? '';

    try {

        if (!hash_equals($_SESSION['csrf_token'], $_POST['csrf_token'] ?? '')) {
            throw new RuntimeException('Invalid request. Please refresh the page.');
        }

        /* ADD INVENTORY */

        if ($action === 'add_inventory') {

            $itemName = trim($_POST['item_name'] ?? '');
            $quantity = filter_var($_POST['quantity'] ?? null, FILTER_VALIDATE_FLOAT);
            $unit = trim($_POST['unit'] ?? '');
            $limit = filter_var($_POST['low_stock_limit'] ?? null, FILTER_VALIDATE_FLOAT);

            if (
                $itemName === '' ||
                $unit === '' ||
                $quantity === false ||
                $limit === false ||
                $quantity < 0 ||
                $limit < 0 ||
                strlen($itemName) > 100 ||
                strlen($unit) > 30
            ) {
                throw new InvalidArgumentException('Please enter valid inventory details.');
            }

            $stmt = $conn->prepare(
                "INSERT INTO inventory (item_name, quantity, unit, low_stock_limit)
                 VALUES (?, ?, ?, ?)"
            );

            $stmt->bind_param('sdsd', $itemName, $quantity, $unit, $limit);
            $stmt->execute();

            goInventory('inventory_added');
        }

        /* UPDATE INVENTORY QUANTITY AND UNIT */

        if ($action === 'update_quantity') {

            $inventoryId = filter_var(
                $_POST['inventory_id'] ?? null,
                FILTER_VALIDATE_INT
            );

            $quantity = filter_var(
                $_POST['quantity'] ?? null,
                FILTER_VALIDATE_FLOAT
            );

            $unit = trim($_POST['unit'] ?? '');

            if (
                !$inventoryId ||
                $quantity === false ||
                $quantity < 0 ||
                $unit === '' ||
                strlen($unit) > 30
            ) {
                throw new InvalidArgumentException(
                    'Please enter a valid quantity and unit.'
                );
            }

            $stmt = $conn->prepare(
                "UPDATE inventory
                 SET quantity = ?, unit = ?
                 WHERE inventory_id = ?"
            );

            $stmt->bind_param('dsi', $quantity, $unit, $inventoryId);
            $stmt->execute();

            goInventory('inventory_updated');
        }

        /* DELETE INVENTORY */

        if ($action === 'delete_inventory') {

            $inventoryId = filter_var(
                $_POST['inventory_id'] ?? null,
                FILTER_VALIDATE_INT
            );

            if (!$inventoryId) {
                throw new InvalidArgumentException('Invalid inventory item.');
            }

            $stmt = $conn->prepare(
                "DELETE FROM inventory WHERE inventory_id = ?"
            );

            $stmt->bind_param('i', $inventoryId);
            $stmt->execute();

            goInventory('inventory_deleted');
        }

        /* ADD PRODUCT */

        if ($action === 'add_product') {

            $productName = trim($_POST['product_name'] ?? '');
            $price = filter_var($_POST['price'] ?? null, FILTER_VALIDATE_FLOAT);
            $categoryId = filter_var($_POST['category_id'] ?? null, FILTER_VALIDATE_INT);
            $image = trim($_POST['image'] ?? '');
            $availability = $_POST['availability'] ?? 'available';

            if (
                $productName === '' ||
                $price === false ||
                $price < 0 ||
                !$categoryId ||
                strlen($productName) > 100 ||
                strlen($image) > 255 ||
                !in_array($availability, ['available', 'unavailable'], true)
            ) {
                throw new InvalidArgumentException('Please enter valid product details.');
            }

            $stmt = $conn->prepare(
                "INSERT INTO products
                    (category_id, product_name, image, price, availability)
                 VALUES (?, ?, ?, ?, ?)"
            );

            $stmt->bind_param(
                'issds',
                $categoryId,
                $productName,
                $image,
                $price,
                $availability
            );

            $stmt->execute();

            goInventory('product_added');
        }

        /* REMOVE PRODUCT - SOFT REMOVE */

        if ($action === 'delete_product') {

            $productId = filter_var(
                $_POST['product_id'] ?? null,
                FILTER_VALIDATE_INT
            );

            if (!$productId) {
                throw new InvalidArgumentException('Invalid product.');
            }

            $stmt = $conn->prepare(
                "UPDATE products
                 SET availability = 'unavailable'
                 WHERE product_id = ?"
            );

            $stmt->bind_param('i', $productId);
            $stmt->execute();

            goInventory('product_unavailable');
        }

        /* RESTORE PRODUCT */

        if ($action === 'toggle_product_availability') {

            $productId = filter_var(
                $_POST['product_id'] ?? null,
                FILTER_VALIDATE_INT
            );

            $newAvailability = $_POST['new_availability'] ?? '';

            if (
                !$productId ||
                !in_array($newAvailability, ['available', 'unavailable'], true)
            ) {
                throw new InvalidArgumentException('Invalid product availability.');
            }

            $stmt = $conn->prepare(
                "UPDATE products
                 SET availability = ?
                 WHERE product_id = ?"
            );

            $stmt->bind_param('si', $newAvailability, $productId);
            $stmt->execute();

            goInventory(
                $newAvailability === 'available'
                    ? 'product_restored'
                    : 'product_unavailable'
            );
        }

    } catch (InvalidArgumentException $ex) {

        $message = $ex->getMessage();
        $messageType = 'error';

    } catch (Throwable $ex) {

        error_log('Inventory page error: ' . $ex->getMessage());

        $message = 'Unable to complete the action. The item may be connected to other records.';
        $messageType = 'error';
    }
}

/* =========================
   MESSAGE DISPLAY
========================= */

$messages = [
    'inventory_added' => 'Inventory item added successfully.',
    'inventory_updated' => 'Inventory quantity and unit updated successfully.',
    'inventory_deleted' => 'Inventory item removed successfully.',
    'product_added' => 'Menu product added successfully.',
    'product_unavailable' => 'Product is now unavailable in the POS menu.',
    'product_restored' => 'Product is now available in the POS menu.'
];

if (isset($_GET['message']) && isset($messages[$_GET['message']])) {
    $message = $messages[$_GET['message']];
    $messageType = 'success';
}

/* =========================
   INVENTORY DATA
========================= */

$items = $inventory->getAllItems();
$totalItems = $inventory->getTotalItems();
$lowStockCount = $inventory->getLowStockCount();

/* =========================
   PRODUCTS
========================= */

$products = [];

$productResult = $conn->query(
    "SELECT
        p.product_id,
        p.product_name,
        p.price,
        p.image,
        p.availability,
        p.category_id,
        c.category_name
     FROM products p
     LEFT JOIN categories c ON p.category_id = c.category_id
     ORDER BY p.category_id ASC, p.product_name ASC"
);

if ($productResult) {
    while ($row = $productResult->fetch_assoc()) {
        $products[] = $row;
    }
}

/* =========================
   CATEGORIES
========================= */

$categories = [];

$categoryResult = $conn->query(
    "SELECT category_id, category_name
     FROM categories
     ORDER BY category_name ASC"
);

if ($categoryResult) {
    while ($row = $categoryResult->fetch_assoc()) {
        $categories[] = $row;
    }
}

?>

<!DOCTYPE html>
<html lang="en">
<head>

    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Nook32 Coffee | Inventory Management</title>

    <style>

        * {
            box-sizing: border-box;
        }

        body {
            margin: 0;
            font-family: Arial, sans-serif;
            background: #f7f1e8;
            color: #39271f;
        }

        .main-header {
            background: #39271f;
            color: #fff8ed;
            padding: 20px 6%;
            display: flex;
            justify-content: space-between;
            align-items: center;
            gap: 20px;
            flex-wrap: wrap;
            box-shadow: 0 3px 12px rgba(0,0,0,0.15);
        }

        .brand {
            display: flex;
            align-items: center;
            gap: 14px;
        }

        .logo {
            width: 75px;
            height: 75px;
            object-fit: contain;
            mix-blend-mode: screen;
        }

        .brand-text h1 {
            margin: 0;
            font-size: 27px;
        }

        .brand-text p {
            margin: 7px 0 0;
            color: #dfcbb7;
        }

        .navbar {
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 10px;
            flex-wrap: wrap;
        }

        .navbar a {
            padding: 9px 16px;
            border: 1px solid #a98a70;
            border-radius: 25px;
            color: #fff8ed;
            text-decoration: none;
            font-size: 14px;
        }

        .navbar a:hover,
        .navbar a.active {
            background: #fff8ed;
            color: #39271f;
        }

        main {
            max-width: 1400px;
            margin: 35px auto;
            padding: 0 20px;
        }

        .subtitle {
            color: #806c5d;
            line-height: 1.6;
        }

        .stats {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(210px, 1fr));
            gap: 18px;
            margin: 25px 0;
        }

        .stat-card,
        .panel {
            background: #fffdf9;
            border: 1px solid #e8dbcd;
            border-radius: 16px;
            padding: 22px;
            box-shadow: 0 4px 14px rgba(57, 39, 31, 0.04);
        }

        .stat-card p {
            color: #806c5d;
            margin: 0 0 12px;
        }

        .stat-card h3 {
            font-size: 27px;
            margin: 0;
        }

        .panel {
            margin-bottom: 25px;
        }

        .panel h3 {
            margin-top: 0;
        }

        .form-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(190px, 1fr));
            gap: 16px;
        }

        .form-group {
            display: flex;
            flex-direction: column;
            gap: 7px;
        }

        label {
            font-weight: bold;
            font-size: 14px;
        }

        input,
        select {
            width: 100%;
            padding: 11px 12px;
            border: 1px solid #dfcbb7;
            border-radius: 8px;
            background: #fffdf9;
            color: #39271f;
            font: inherit;
        }

        input:focus,
        select:focus {
            outline: 2px solid #a98a70;
            outline-offset: 1px;
        }

        button {
            border: none;
            border-radius: 8px;
            background: #654633;
            color: #fff8ed;
            padding: 11px 15px;
            font-weight: bold;
            cursor: pointer;
            font: inherit;
        }

        button:hover {
            background: #39271f;
        }

        .delete-button {
            background: #8b3030;
        }

        .delete-button:hover {
            background: #641f1f;
        }

        .save-button {
            background: #654633;
        }

        .save-button:hover {
            background: #39271f;
        }

        .submit-row {
            margin-top: 18px;
        }

        .table-container {
            overflow-x: auto;
        }

        table {
            width: 100%;
            min-width: 850px;
            border-collapse: collapse;
        }

        th,
        td {
            padding: 13px 10px;
            text-align: left;
            border-bottom: 1px solid #e8dbcd;
            vertical-align: middle;
        }

        th {
            background: #eee1d1;
            white-space: nowrap;
        }

        tr:last-child td {
            border-bottom: none;
        }

        .status {
            display: inline-block;
            padding: 6px 10px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: bold;
            white-space: nowrap;
        }

        .status.in-stock {
            background: #dcefdc;
            color: #24632b;
        }

        .status.low-stock {
            background: #fff0c2;
            color: #795b00;
        }

        .status.out-stock {
            background: #f8d7da;
            color: #842029;
        }

        .status.available {
            background: #dcefdc;
            color: #24632b;
        }

        .status.unavailable {
            background: #f8d7da;
            color: #842029;
        }

        .message {
            padding: 13px 16px;
            border-radius: 8px;
            margin: 18px 0;
            overflow-wrap: anywhere;
        }

        .message.success {
            background: #dcefdc;
            color: #24632b;
        }

        .message.error {
            background: #f8d7da;
            color: #842029;
        }

        .empty {
            text-align: center;
            padding: 22px;
            color: #806c5d;
        }

        .dashboard-links {
            display: flex;
            gap: 10px;
            flex-wrap: wrap;
            margin-top: 22px;
        }

        .dashboard-links a {
            display: inline-block;
            background: #654633;
            color: #fff8ed;
            text-decoration: none;
            border-radius: 9px;
            padding: 11px 15px;
        }

        .dashboard-links a:hover {
            background: #39271f;
        }

        .action-buttons {
            display: flex;
            align-items: center;
            gap: 7px;
            flex-wrap: wrap;
        }

        .action-buttons button {
            padding: 9px 12px;
            font-size: 14px;
        }

        .inventory-update-form {
            display: flex;
            align-items: center;
            gap: 7px;
            min-width: 220px;
        }

        .inventory-update-form input,
        .inventory-update-form select {
            padding: 9px 8px;
            min-width: 85px;
        }

        .inventory-update-form select {
            min-width: 100px;
        }

        .inventory-update-form button {
            white-space: nowrap;
            padding: 9px 12px;
        }

        footer {
            text-align: center;
            color: #806c5d;
            padding: 35px 15px;
        }

        @media (max-width: 600px) {

            .main-header {
                align-items: flex-start;
                flex-direction: column;
            }

            .stat-card h3 {
                font-size: 24px;
            }

        }

        /* FOOTER */

.site-footer {
    background: #39271f;
    color: #fffdf9;
    padding: 40px 7% 15px;
    margin-top: 50px;
}

.footer-content {
    display: flex;
    justify-content: space-between;
    align-items: flex-start;
    flex-wrap: wrap;
    gap: 35px;
    max-width: 1200px;
    margin: auto;
}

.footer-content h2 {
    margin: 0 0 10px;
    font-size: 22px;
}

.footer-content h3 {
    font-size: 15px;
    margin-bottom: 15px;
    color: #d7b998;
}

.footer-content p {
    color: #dfcbb7;
    font-size: 14px;
}

.social-icons {
    display: flex;
    gap: 12px;
}

.social-icons a {
    width: 40px;
    height: 40px;
    border-radius: 50%;
    background: #fffdf9;
    color: #654633;
    display: flex;
    justify-content: center;
    align-items: center;
    transition: 0.3s;
}

.social-icons a:hover {
    background: #d7b998;
    transform: translateY(-4px);
}

.social-icons svg {
    width: 21px;
    height: 21px;
    fill: currentColor;
    stroke: currentColor;
    stroke-width: 1.8;
}

.footer-bottom {
    border-top: 1px solid #765b48;
    text-align: center;
    margin-top: 30px;
    padding-top: 15px;
}

.footer-bottom p {
    font-size: 12px;
    color: #cbb8a7;
}

    </style>

</head>

<body>

<header class="main-header">

    <div class="brand">

        <img src="assets/images/logo.png"
             alt="Nook32 Coffee Logo"
             class="logo">

        <div class="brand-text">
            <h1>NOOK32 COFFEE</h1>
            <p>Inventory and Stock Management</p>
        </div>

    </div>

    <nav class="navbar">

        <a href="index.php">POS Menu</a>
        <a href="order_history.php">Order History</a>
        <a href="dashboard.php">Sales Dashboard</a>
        <a href="inventory.php" class="active">Inventory</a>
        <a href="manage_users.php">Manage Users</a>
        <a href="logout.php">Logout</a>

    </nav>

</header>

<main>

    <h2>Inventory Management</h2>

    <p class="subtitle">
        Monitor available stock and manage menu products.
    </p>

    <?php if ($message !== ''): ?>

        <div class="message <?= e($messageType) ?>">
            <?= e($message) ?>
        </div>

    <?php endif; ?>

    <!-- SUMMARY -->

    <section class="stats">

        <article class="stat-card">
            <p>Total Inventory Items</p>
            <h3><?= number_format($totalItems) ?></h3>
        </article>

        <article class="stat-card">
            <p>Low-Stock Items</p>
            <h3><?= number_format($lowStockCount) ?></h3>
        </article>

        <article class="stat-card">
            <p>Total Menu Products</p>
            <h3><?= number_format(count($products)) ?></h3>
        </article>

    </section>

    <!-- ADD INVENTORY -->

    <section class="panel">

        <h3>Add Inventory Item</h3>

        <p class="subtitle">
            Add ingredients or other stock used by your coffee shop.
        </p>

        <form method="POST" action="inventory.php">

            <input type="hidden" name="action" value="add_inventory">
            <input type="hidden" name="csrf_token" value="<?= e($csrfToken) ?>">

            <div class="form-grid">

                <div class="form-group">

                    <label for="item_name">Item Name</label>

                    <input type="text"
                           id="item_name"
                           name="item_name"
                           maxlength="100"
                           placeholder="e.g. Coffee Beans"
                           required>

                </div>

                <div class="form-group">

                    <label for="quantity">Current Quantity</label>

                    <input type="number"
                           id="quantity"
                           name="quantity"
                           min="0"
                           step="0.01"
                           placeholder="e.g. 10"
                           required>

                </div>

                <div class="form-group">

                    <label for="unit">Unit</label>

                    <select id="unit" name="unit" required>

                        <option value="">Select unit</option>
                        <option value="kg">Kilograms (kg)</option>
                        <option value="g">Grams (g)</option>
                        <option value="L">Liters (L)</option>
                        <option value="mL">Milliliters (mL)</option>
                        <option value="bottle">Bottles</option>
                        <option value="pack">Packs</option>
                        <option value="pcs">Pieces</option>
                        <option value="box">Boxes</option>

                    </select>

                </div>

                <div class="form-group">

                    <label for="low_stock_limit">Low-Stock Limit</label>

                    <input type="number"
                           id="low_stock_limit"
                           name="low_stock_limit"
                           min="0"
                           step="0.01"
                           value="5"
                           required>

                </div>

            </div>

            <div class="submit-row">

                <button type="submit">
                    Add Inventory Item
                </button>

            </div>

        </form>

    </section>

    <!-- CURRENT INVENTORY -->

    <section class="panel">

        <h3>Current Inventory</h3>

        <p class="subtitle">
            Update stock quantities and units, or remove inventory items when necessary.
        </p>

        <div class="table-container">

            <table>

                <thead>

                    <tr>
                        <th>ID</th>
                        <th>Item Name</th>
                        <th>Quantity</th>
                        <th>Unit</th>
                        <th>Low-Stock Limit</th>
                        <th>Status</th>
                        <th>Actions</th>
                    </tr>

                </thead>

                <tbody>

                <?php if (!empty($items)): ?>

                    <?php foreach ($items as $item): ?>

                        <?php

                        $quantity = (float)$item['quantity'];
                        $limit = (float)$item['low_stock_limit'];

                        if ($quantity <= 0) {
                            $status = 'out-stock';
                            $statusText = 'Out of Stock';
                        } elseif ($quantity <= $limit) {
                            $status = 'low-stock';
                            $statusText = 'Low Stock';
                        } else {
                            $status = 'in-stock';
                            $statusText = 'In Stock';
                        }

                        $units = [
                            'kg' => 'Kilograms (kg)',
                            'g' => 'Grams (g)',
                            'L' => 'Liters (L)',
                            'mL' => 'Milliliters (mL)',
                            'bottle' => 'Bottles',
                            'pack' => 'Packs',
                            'pcs' => 'Pieces',
                            'box' => 'Boxes'
                        ];

                        ?>

                        <tr>

                            <td>
                                <?= (int)$item['inventory_id'] ?>
                            </td>

                            <td>
                                <?= e($item['item_name']) ?>
                            </td>

                            <!-- QUANTITY AND UNIT UPDATE FORM -->

                            <td colspan="2">

                                <form method="POST"
                                      action="inventory.php"
                                      class="inventory-update-form">

                                    <input type="hidden"
                                           name="action"
                                           value="update_quantity">

                                    <input type="hidden"
                                           name="csrf_token"
                                           value="<?= e($csrfToken) ?>">

                                    <input type="hidden"
                                           name="inventory_id"
                                           value="<?= (int)$item['inventory_id'] ?>">

                                    <input type="number"
                                           name="quantity"
                                           min="0"
                                           step="0.01"
                                           value="<?= e($quantity) ?>"
                                           required
                                           aria-label="Quantity for <?= e($item['item_name']) ?>">

                                    <select name="unit"
                                            required
                                            aria-label="Unit for <?= e($item['item_name']) ?>">

                                        <?php if (!isset($units[$item['unit']])): ?>

                                            <option value="<?= e($item['unit']) ?>" selected>
                                                <?= e($item['unit']) ?>
                                            </option>

                                        <?php endif; ?>

                                        <?php foreach ($units as $unitValue => $unitLabel): ?>

                                            <option value="<?= e($unitValue) ?>"
                                                <?= $item['unit'] === $unitValue ? 'selected' : '' ?>>

                                                <?= e($unitLabel) ?>

                                            </option>

                                        <?php endforeach; ?>

                                    </select>

                                    <button type="submit" class="save-button">
                                        Save
                                    </button>

                                </form>

                            </td>

                            <td>
                                <?= number_format($limit, 2) ?>
                            </td>

                            <td>

                                <span class="status <?= e($status) ?>">
                                    <?= e($statusText) ?>
                                </span>

                            </td>

                            <td>

                                <form method="POST"
                                      action="inventory.php"
                                      onsubmit="return confirm('Are you sure you want to remove this inventory item?');">

                                    <input type="hidden"
                                           name="action"
                                           value="delete_inventory">

                                    <input type="hidden"
                                           name="csrf_token"
                                           value="<?= e($csrfToken) ?>">

                                    <input type="hidden"
                                           name="inventory_id"
                                           value="<?= (int)$item['inventory_id'] ?>">

                                    <button type="submit" class="delete-button">
                                        Remove
                                    </button>

                                </form>

                            </td>

                        </tr>

                    <?php endforeach; ?>

                <?php else: ?>

                    <tr>

                        <td colspan="7" class="empty">
                            No inventory items yet.
                        </td>

                    </tr>

                <?php endif; ?>

                </tbody>

            </table>

        </div>

    </section>

    <!-- ADD PRODUCT -->

    <section class="panel">

        <h3>Add Menu Product</h3>

        <p class="subtitle">
            Add new products that will appear in the POS menu.
        </p>

        <form method="POST" action="inventory.php">

            <input type="hidden" name="action" value="add_product">
            <input type="hidden" name="csrf_token" value="<?= e($csrfToken) ?>">

            <div class="form-grid">

                <div class="form-group">

                    <label for="product_name">Product Name</label>

                    <input type="text"
                           name="product_name"
                           id="product_name"
                           maxlength="100"
                           placeholder="e.g. Iced Spanish Latte"
                           required>

                </div>

                <div class="form-group">

                    <label for="product_price">Price (₱)</label>

                    <input type="number"
                           name="price"
                           id="product_price"
                           min="0"
                           step="0.01"
                           placeholder="0.00"
                           required>

                </div>

                <div class="form-group">

                    <label for="product_category">Category</label>

                    <select name="category_id"
                            id="product_category"
                            required>

                        <option value="">Select category</option>

                        <?php foreach ($categories as $category): ?>

                            <option value="<?= (int)$category['category_id'] ?>">

                                <?= e($category['category_name']) ?>

                            </option>

                        <?php endforeach; ?>

                    </select>

                </div>

                <div class="form-group">

                    <label for="product_image">Image Filename</label>

                    <input type="text"
                           name="image"
                           id="product_image"
                           maxlength="255"
                           placeholder="e.g. spanish_latte.jpg">

                </div>

                <div class="form-group">

                    <label for="product_availability">Availability</label>

                    <select name="availability"
                            id="product_availability">

                        <option value="available">Available</option>
                        <option value="unavailable">Unavailable</option>

                    </select>

                </div>

            </div>

            <div class="submit-row">

                <button type="submit">
                    Add Product
                </button>

            </div>

        </form>

    </section>

    <!-- MENU PRODUCTS -->

    <section class="panel">

        <h3>Manage Menu Products</h3>

        <p class="subtitle">
            Remove products from the POS menu or restore unavailable products.
        </p>

        <div class="table-container">

            <table>

                <thead>

                    <tr>
                        <th>ID</th>
                        <th>Product Name</th>
                        <th>Price</th>
                        <th>Category</th>
                        <th>Availability</th>
                        <th>Actions</th>
                    </tr>

                </thead>

                <tbody>

                <?php if (!empty($products)): ?>

                    <?php foreach ($products as $product): ?>

                        <tr>

                            <td>
                                <?= (int)$product['product_id'] ?>
                            </td>

                            <td>
                                <?= e($product['product_name']) ?>
                            </td>

                            <td>
                                ₱<?= number_format((float)$product['price'], 2) ?>
                            </td>

                            <td>
                                <?= e($product['category_name'] ?? 'Uncategorized') ?>
                            </td>

                            <td>

                                <span class="status <?= $product['availability'] === 'available' ? 'available' : 'unavailable' ?>">

                                    <?= e(ucfirst($product['availability'])) ?>

                                </span>

                            </td>

                            <td>

                                <div class="action-buttons">

                                    <?php if ($product['availability'] === 'available'): ?>

                                        <form method="POST"
                                              action="inventory.php"
                                              onsubmit="return confirm('Are you sure you want to make this product unavailable?');">

                                            <input type="hidden"
                                                   name="action"
                                                   value="delete_product">

                                            <input type="hidden"
                                                   name="csrf_token"
                                                   value="<?= e($csrfToken) ?>">

                                            <input type="hidden"
                                                   name="product_id"
                                                   value="<?= (int)$product['product_id'] ?>">

                                            <button type="submit" class="delete-button">
                                                Remove
                                            </button>

                                        </form>

                                    <?php else: ?>

                                        <form method="POST"
                                              action="inventory.php"
                                              onsubmit="return confirm('Make this product available again in the POS menu?');">

                                            <input type="hidden"
                                                   name="action"
                                                   value="toggle_product_availability">

                                            <input type="hidden"
                                                   name="new_availability"
                                                   value="available">

                                            <input type="hidden"
                                                   name="csrf_token"
                                                   value="<?= e($csrfToken) ?>">

                                            <input type="hidden"
                                                   name="product_id"
                                                   value="<?= (int)$product['product_id'] ?>">

                                            <button type="submit">
                                                Make Available
                                            </button>

                                        </form>

                                    <?php endif; ?>

                                </div>

                            </td>

                        </tr>

                    <?php endforeach; ?>

                <?php else: ?>

                    <tr>

                        <td colspan="6" class="empty">
                            No menu products found.
                        </td>

                    </tr>

                <?php endif; ?>

                </tbody>

            </table>

        </div>

    </section>

</main>

<!-- FOOTER -->

<footer class="site-footer">

    <div class="footer-content">

        <div class="footer-brand">
            <h3>NOOK32 COFFEE ☕</h3>
            <p>Good coffee, cozy moments.</p>
        </div>

        <div class="footer-location">
            <h3>VISIT OUR SHOP</h3>
            <p>📍 No. 5 Mckinley St., Binmaley, Pangasinan</p>
        </div>

        <div class="footer-social">
            <h3>FOLLOW US</h3>

            <div class="social-icons">

                <a
                    href="https://facebook.com/nook32coffee"
                    target="_blank"
                    rel="noopener noreferrer"
                    aria-label="Facebook"
                >
                    <svg viewBox="0 0 24 24">
                        <path d="M13.5 21v-8h2.7l.4-3h-3.1V8.1c0-.9.3-1.5 1.6-1.5h1.7V3.9c-.3 0-1.3-.1-2.5-.1-2.5 0-4.2 1.5-4.2 4.3V10H7.5v3h2.6v8z"/>
                    </svg>
                </a>

                <a
                    href="https://instagram.com/nook32coffee"
                    target="_blank"
                    rel="noopener noreferrer"
                    aria-label="Instagram"
                >
                    <svg viewBox="0 0 24 24">
                        <rect x="3" y="3" width="18" height="18" rx="5"/>
                        <circle cx="12" cy="12" r="4"/>
                        <circle cx="17.5" cy="6.5" r="1" fill="currentColor" stroke="none"/>
                    </svg>
                </a>

                <a
                    href="https://tiktok.com/@nook32coffee"
                    target="_blank"
                    rel="noopener noreferrer"
                    aria-label="TikTok"
                >
                    <svg viewBox="0 0 24 24">
                        <path d="M14 3v11.2a3.2 3.2 0 1 1-3-3.2V8a6.2 6.2 0 1 0 6.2 6.2V9.1c1.3 1 2.8 1.5 4.3 1.6V7.5c-2.4-.2-4.1-1.8-4.5-4.5z"/>
                    </svg>
                </a>

            </div>
        </div>

    </div>

    <div class="footer-bottom">
        <p>© <?= date('Y') ?> Nook32 Coffee. All Rights Reserved.</p>
    </div>

</footer>

</body>
</html>
