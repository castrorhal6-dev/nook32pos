<?php
require_once __DIR__ . '/auth.php';
requireRole('admin');

require_once __DIR__ . '/classes/Database.php';
require_once __DIR__ . '/classes/InventoryManager.php';

$database = new Database();
$inventory = new InventoryManager($database);

$message = '';
$messageType = 'success';

// Add or update inventory items
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';

    try {
        if ($action === 'add') {
            $itemName = trim($_POST['item_name'] ?? '');
            $quantity = filter_var(
                $_POST['quantity'] ?? null,
                FILTER_VALIDATE_FLOAT
            );
            $unit = trim($_POST['unit'] ?? '');
            $lowStockLimit = filter_var(
                $_POST['low_stock_limit'] ?? null,
                FILTER_VALIDATE_FLOAT
            );

            if (
                $itemName === '' ||
                $unit === '' ||
                $quantity === false ||
                $quantity === null ||
                $lowStockLimit === false ||
                $lowStockLimit === null ||
                $quantity < 0 ||
                $lowStockLimit < 0 ||
                strlen($itemName) > 100 ||
                strlen($unit) > 30
            ) {
                throw new InvalidArgumentException(
                    'Please enter valid item details and non-negative quantities.'
                );
            }

            $stmt = $database->getConnection()->prepare(
                "INSERT INTO inventory
                    (item_name, quantity, unit, low_stock_limit)
                 VALUES (?, ?, ?, ?)"
            );

            $stmt->bind_param(
                'sdsd',
                $itemName,
                $quantity,
                $unit,
                $lowStockLimit
            );

            $stmt->execute();

            header('Location: inventory.php?message=added');
            exit;
        }

        if ($action === 'update') {
            $inventoryId = filter_var(
                $_POST['inventory_id'] ?? null,
                FILTER_VALIDATE_INT
            );

            $quantity = filter_var(
                $_POST['quantity'] ?? null,
                FILTER_VALIDATE_FLOAT
            );

            if (
                !$inventoryId ||
                $quantity === false ||
                $quantity === null ||
                $quantity < 0
            ) {
                throw new InvalidArgumentException(
                    'Please enter a valid item and a non-negative quantity.'
                );
            }

            $stmt = $database->getConnection()->prepare(
                "UPDATE inventory
                 SET quantity = ?
                 WHERE inventory_id = ?"
            );

            $stmt->bind_param(
                'di',
                $quantity,
                $inventoryId
            );

            $stmt->execute();

            header('Location: inventory.php?message=updated');
            exit;
        }
    } catch (Throwable $e) {
        if ($e instanceof InvalidArgumentException) {
            $message = $e->getMessage();
        } else {
            error_log('Nook32 inventory error: ' . $e->getMessage());
            $message = 'Something went wrong. Please try again.';
        }

        $messageType = 'error';
    }
}

// Display success messages after saving
if (isset($_GET['message'])) {
    if ($_GET['message'] === 'added') {
        $message = 'Inventory item added successfully.';
    } elseif ($_GET['message'] === 'updated') {
        $message = 'Stock quantity updated successfully.';
    }

    $messageType = 'success';
}

// Retrieve inventory records
$items = $inventory->getAllItems();
$totalItems = $inventory->getTotalItems();
$lowStockCount = $inventory->getLowStockCount();

function e($value): string
{
    return htmlspecialchars(
        (string) $value,
        ENT_QUOTES,
        'UTF-8'
    );
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Nook32 Coffee | Inventory Management</title>

    <style>
        * {
            box-sizing: border-box;
        }

        body {
            margin: 0;
            font-family: Arial, sans-serif;
            background: #f7f1e8;
            color: #39271f;
        }

        header {
            background: #39271f;
            color: #fff8ed;
            padding: 24px 6%;
            display: flex;
            justify-content: space-between;
            align-items: center;
            gap: 15px;
            flex-wrap: wrap;
        }

        header h1 {
            margin: 0;
            font-size: 26px;
        }

        header p {
            color: #dfcbb7;
            margin-bottom: 0;
        }

        nav {
            display: flex;
            flex-wrap: wrap;
            gap: 10px;
        }

        nav a {
            color: #fff8ed;
            text-decoration: none;
            border: 1px solid #a98a70;
            border-radius: 9px;
            padding: 10px 14px;
        }

        nav a:hover,
        nav a.active {
            background: #654633;
        }

        main {
            max-width: 1200px;
            margin: 35px auto;
            padding: 0 20px;
        }

        .subtitle {
            color: #806c5d;
            line-height: 1.6;
        }

        .stats {
            display: grid;
            grid-template-columns: repeat(
                auto-fit,
                minmax(210px, 1fr)
            );
            gap: 18px;
            margin: 25px 0;
        }

        .stat-card,
        .panel {
            background: #fffdf9;
            border: 1px solid #e8dbcd;
            border-radius: 16px;
            padding: 22px;
            box-shadow: 0 4px 14px rgba(57, 39, 31, 0.04);
        }

        .stat-card p {
            color: #806c5d;
            margin: 0 0 12px;
        }

        .stat-card h3 {
            font-size: 27px;
            margin: 0;
        }

        .panel {
            margin-bottom: 25px;
        }

        .panel h3 {
            margin-top: 0;
        }

        .form-grid {
            display: grid;
            grid-template-columns: repeat(
                auto-fit,
                minmax(190px, 1fr)
            );
            gap: 16px;
        }

        .form-group {
            display: flex;
            flex-direction: column;
            gap: 7px;
        }

        label {
            font-weight: bold;
            font-size: 14px;
        }

        input,
        select {
            width: 100%;
            padding: 11px 12px;
            border: 1px solid #dfcbb7;
            border-radius: 8px;
            background: #fffdf9;
            color: #39271f;
            font: inherit;
        }

        input:focus,
        select:focus {
            outline: 2px solid #a98a70;
            outline-offset: 1px;
        }

        button {
            border: none;
            border-radius: 8px;
            background: #654633;
            color: #fff8ed;
            padding: 11px 15px;
            font-weight: bold;
            cursor: pointer;
            font: inherit;
        }

        button:hover {
            background: #39271f;
        }

        .submit-row {
            margin-top: 18px;
        }

        .table-container {
            overflow-x: auto;
        }

        table {
            width: 100%;
            min-width: 750px;
            border-collapse: collapse;
        }

        th,
        td {
            padding: 13px 10px;
            text-align: left;
            border-bottom: 1px solid #e8dbcd;
        }

        th {
            background: #eee1d1;
            white-space: nowrap;
        }

        tr:last-child td {
            border-bottom: none;
        }

        .quantity-input {
            width: 110px;
        }

        .update-form {
            display: flex;
            align-items: center;
            gap: 8px;
        }

        .status {
            display: inline-block;
            padding: 6px 10px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: bold;
            white-space: nowrap;
        }

        .status.in-stock {
            background: #dcefdc;
            color: #24632b;
        }

        .status.low-stock {
            background: #fff0c2;
            color: #795b00;
        }

        .status.out-stock {
            background: #f8d7da;
            color: #842029;
        }

        .message {
            padding: 13px 16px;
            border-radius: 8px;
            margin: 18px 0;
            overflow-wrap: anywhere;
        }

        .message.success {
            background: #dcefdc;
            color: #24632b;
        }

        .message.error {
            background: #f8d7da;
            color: #842029;
        }

        .empty {
            text-align: center;
            padding: 22px;
            color: #806c5d;
        }

        .dashboard-links {
            display: flex;
            gap: 10px;
            flex-wrap: wrap;
            margin-top: 22px;
        }

        .dashboard-links a {
            display: inline-block;
            background: #654633;
            color: #fff8ed;
            text-decoration: none;
            border-radius: 9px;
            padding: 11px 15px;
        }

        .dashboard-links a:hover {
            background: #39271f;
        }

        footer {
            text-align: center;
            color: #806c5d;
            padding: 35px 15px;
        }

        @media (max-width: 600px) {
            header {
                align-items: flex-start;
                flex-direction: column;
            }

            .stat-card h3 {
                font-size: 24px;
            }

            .update-form {
                align-items: flex-start;
                flex-direction: column;
            }
        }
        .main-header {
    background: #39271f;
    color: #fff8ed;
    padding: 20px 6%;
    display: flex;
    justify-content: space-between;
    align-items: center;
    gap: 20px;
    flex-wrap: wrap;
    box-shadow: 0 3px 12px rgba(0,0,0,0.15);
}

.brand {
    display: flex;
    align-items: center;
    gap: 14px;
}

.logo {
    width: 75px;
    height: 75px;
    object-fit: contain;
    mix-blend-mode: screen;
}

.brand-text h1 {
    margin: 0;
    font-size: 27px;
}

.brand-text p {
    margin: 7px 0 0;
    color: #dfcbb7;
}

.navbar {
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 10px;
    flex-wrap: wrap;
}

.navbar a {
    padding: 9px 16px;
    border: 1px solid #a98a70;
    border-radius: 25px;
    color: #fff8ed;
    text-decoration: none;
    font-size: 14px;
}

.navbar a:hover,
.navbar a.active {
    background: #fff8ed;
    color: #39271f;
}
    </style>
</head>

<body>

<header class="main-header">

    <div class="brand">
        <img
            src="assets/images/logo.png"
            alt="Nook32 Coffee Logo"
            class="logo"
        >

        <div class="brand-text">
            <h1>NOOK32 COFFEE</h1>
            <p>Inventory and Stock Management</p>
        </div>
    </div>

    <nav class="navbar">
        <a href="index.php">POS Menu</a>
        <a href="order_history.php">Order History</a>
        <a href="dashboard.php">Dashboard</a>
        <a href="inventory.php" class="active">Inventory</a>
        <a href="logout.php">Logout</a>
    </nav>

</header>

<main>
    <h2>Inventory Management</h2>

    <p class="subtitle">
        Monitor available stock and update inventory quantities.
    </p>

    <?php if ($message !== ''): ?>
        <div class="message <?= e($messageType) ?>">
            <?= e($message) ?>
        </div>
    <?php endif; ?>

    <!-- Inventory summary -->
    <section class="stats">
        <article class="stat-card">
            <p>Total Inventory Items</p>
            <h3><?= number_format($totalItems) ?></h3>
        </article>

        <article class="stat-card">
            <p>Low-Stock Items</p>
            <h3><?= number_format($lowStockCount) ?></h3>
        </article>
    </section>

    <!-- Add inventory item -->
    <section class="panel">
        <h3>Add Inventory Item</h3>

        <p class="subtitle">
            Add ingredients or other stock used by your coffee shop.
        </p>

        <form method="POST" action="inventory.php">
            <input type="hidden" name="action" value="add">

            <div class="form-grid">
                <div class="form-group">
                    <label for="item_name">Item Name</label>
                    <input
                        type="text"
                        id="item_name"
                        name="item_name"
                        maxlength="100"
                        placeholder="e.g. Coffee Beans"
                        required
                    >
                </div>

                <div class="form-group">
                    <label for="quantity">Current Quantity</label>
                    <input
                        type="number"
                        id="quantity"
                        name="quantity"
                        min="0"
                        step="0.01"
                        placeholder="e.g. 10"
                        required
                    >
                </div>

                <div class="form-group">
                    <label for="unit">Unit</label>
                    <select id="unit" name="unit" required>
                        <option value="">Select unit</option>
                        <option value="kg">Kilograms (kg)</option>
                        <option value="g">Grams (g)</option>
                        <option value="L">Liters (L)</option>
                        <option value="mL">Milliliters (mL)</option>
                        <option value="bottle">Bottles</option>
                        <option value="pack">Packs</option>
                        <option value="pcs">Pieces</option>
                        <option value="box">Boxes</option>
                    </select>
                </div>

                <div class="form-group">
                    <label for="low_stock_limit">
                        Low-Stock Limit
                    </label>
                    <input
                        type="number"
                        id="low_stock_limit"
                        name="low_stock_limit"
                        min="0"
                        step="0.01"
                        value="5"
                        required
                    >
                </div>
            </div>

            <div class="submit-row">
                <button type="submit">Add Inventory Item</button>
            </div>
        </form>
    </section>

    <!-- Inventory list -->
    <section class="panel">
        <h3>Current Inventory</h3>

        <p class="subtitle">
            Update the quantity when you receive stock or use inventory.
        </p>

        <div class="table-container">
            <table>
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Item Name</th>
                        <th>Quantity</th>
                        <th>Unit</th>
                        <th>Low-Stock Limit</th>
                        <th>Status</th>
                        <th>Update Quantity</th>
                    </tr>
                </thead>

                <tbody>
                <?php if (count($items) > 0): ?>

                    <?php foreach ($items as $item): ?>
                        <?php
                        $quantity = (float) $item['quantity'];
                        $limit = (float) $item['low_stock_limit'];

                        if ($quantity <= 0) {
                            $status = 'out-stock';
                            $statusText = 'Out of Stock';
                        } elseif ($quantity <= $limit) {
                            $status = 'low-stock';
                            $statusText = 'Low Stock';
                        } else {
                            $status = 'in-stock';
                            $statusText = 'In Stock';
                        }
                        ?>

                        <tr>
                            <td>
                                <?= (int) $item['inventory_id'] ?>
                            </td>

                            <td>
                                <?= e($item['item_name']) ?>
                            </td>

                            <td>
                                <?= number_format($quantity, 2) ?>
                            </td>

                            <td>
                                <?= e($item['unit']) ?>
                            </td>

                            <td>
                                <?= number_format($limit, 2) ?>
                            </td>

                            <td>
                                <span class="status <?= e($status) ?>">
                                    <?= e($statusText) ?>
                                </span>
                            </td>

                            <td>
                                <form
                                    class="update-form"
                                    method="POST"
                                    action="inventory.php"
                                >
                                    <input
                                        type="hidden"
                                        name="action"
                                        value="update"
                                    >

                                    <input
                                        type="hidden"
                                        name="inventory_id"
                                        value="<?= (int) $item['inventory_id'] ?>"
                                    >

                                    <input
                                        class="quantity-input"
                                        type="number"
                                        name="quantity"
                                        min="0"
                                        step="0.01"
                                        value="<?= e($item['quantity']) ?>"
                                        aria-label="New quantity for <?= e($item['item_name']) ?>"
                                        required
                                    >

                                    <button type="submit">
                                        Save
                                    </button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; ?>

                <?php else: ?>
                    <tr>
                        <td colspan="7" class="empty">
                            No inventory items yet.
                            Use the form above to add your first item.
                        </td>
                    </tr>
                <?php endif; ?>
                </tbody>
            </table>
        </div>
    </section>

    <div class="dashboard-links">
        <a href="index.php">Open POS Menu</a>
        <a href="dashboard.php">View Sales Dashboard</a>
        <a href="order_history.php">View Order History</a>
    </div>
</main>

<footer>
    Nook32 Coffee · POS and Sales Management System
</footer>

</body>
</html>