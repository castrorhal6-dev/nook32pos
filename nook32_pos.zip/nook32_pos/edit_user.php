<?php
require_once __DIR__ . '/auth.php';
requireRole('admin');

require_once __DIR__ . '/config/database.php';

$message = '';
$messageType = '';

$userId = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);

if (!$userId || $userId < 1) {
    http_response_code(400);
    exit('Invalid user ID.');
}

// Get the selected user
$stmt = $conn->prepare(
    'SELECT user_id, full_name, username, role
     FROM users
     WHERE user_id = ?'
);
$stmt->bind_param('i', $userId);
$stmt->execute();

$user = $stmt->get_result()->fetch_assoc();
$stmt->close();

if (!$user) {
    http_response_code(404);
    exit('User account not found.');
}

$isCurrentUser =
    (int)$user['user_id'] === (int)$_SESSION['user_id'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Validate security token
    if (
        !isset($_POST['csrf_token'], $_SESSION['csrf_token']) ||
        !hash_equals($_SESSION['csrf_token'], $_POST['csrf_token'])
    ) {
        http_response_code(403);
        exit('Invalid security token. Please return and try again.');
    }

    $fullName = trim($_POST['full_name'] ?? '');
    $role = $_POST['role'] ?? '';

    if ($fullName === '') {
        $message = 'Full name is required.';
        $messageType = 'error';
    } elseif (!in_array($role, ['admin', 'cashier'], true)) {
        $message = 'Invalid account role.';
        $messageType = 'error';
    } elseif ($isCurrentUser && $role !== 'admin') {
        $message = 'You cannot change your own admin role.';
        $messageType = 'error';
    } else {
        $update = $conn->prepare(
            'UPDATE users
             SET full_name = ?, role = ?
             WHERE user_id = ?'
        );

        $update->bind_param('ssi', $fullName, $role, $userId);

        if ($update->execute()) {
            $message = 'User account updated successfully.';
            $messageType = 'success';

            // Update the current admin's session name if needed
            if ($isCurrentUser) {
                $_SESSION['full_name'] = $fullName;
            }

            $user['full_name'] = $fullName;
            $user['role'] = $role;
        } else {
            $message = 'Unable to update the account.';
            $messageType = 'error';
        }

        $update->close();
    }
}

function e($value): string
{
    return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8');
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit User | Nook32 Coffee</title>

    <style>
        * {
            box-sizing: border-box;
        }

        body {
            margin: 0;
            padding: 30px 16px;
            font-family: Arial, sans-serif;
            background: #f7f1e8;
            color: #39271f;
        }

        .container {
            max-width: 600px;
            margin: auto;
        }

        .card {
            background: #fffdf9;
            border: 1px solid #dfcbb7;
            border-radius: 16px;
            padding: 25px;
        }

        label {
            display: block;
            margin: 16px 0 7px;
            font-weight: bold;
        }

        input, select {
            width: 100%;
            padding: 12px;
            border: 1px solid #d8c3b0;
            border-radius: 8px;
            font-size: 15px;
        }

        button, .back {
            display: inline-block;
            padding: 12px 18px;
            border: none;
            border-radius: 24px;
            background: #654633;
            color: white;
            text-decoration: none;
            font-weight: bold;
            cursor: pointer;
        }

        button {
            width: 100%;
            margin-top: 22px;
        }

        .message {
            padding: 12px;
            border-radius: 8px;
            margin: 15px 0;
        }

        .success {
            background: #e5f4e8;
            color: #245c32;
        }

        .error {
            background: #fbe8e5;
            color: #8b2e22;
        }

        .note {
            color: #765f50;
            font-size: 13px;
        }
    </style>
</head>
<body>
<div class="container">
    <p>
        <a class="back" href="manage_users.php">
            Back to Manage Users
        </a>
    </p>

    <div class="card">
        <h1>Edit User Account</h1>

        <p>
            Username:
            <strong><?= e($user['username']) ?></strong>
        </p>

        <?php if ($message !== ''): ?>
            <div class="message <?= e($messageType) ?>">
                <?= e($message) ?>
            </div>
        <?php endif; ?>

        <form method="POST">
            <input
                type="hidden"
                name="csrf_token"
                value="<?= e($_SESSION['csrf_token']) ?>"
            >

            <label for="full_name">Full Name</label>
            <input
                type="text"
                id="full_name"
                name="full_name"
                value="<?= e($user['full_name']) ?>"
                required
            >

            <label for="role">Account Role</label>
            <select
                id="role"
                name="role"
                required
                <?= $isCurrentUser ? 'disabled' : '' ?>
            >
                <option
                    value="cashier"
                    <?= $user['role'] === 'cashier' ? 'selected' : '' ?>
                >
                    Cashier
                </option>

                <option
                    value="admin"
                    <?= $user['role'] === 'admin' ? 'selected' : '' ?>
                >
                    Admin
                </option>
            </select>

            <?php if ($isCurrentUser): ?>
                <input type="hidden" name="role" value="admin">
                <p class="note">
                    You cannot change your own admin role.
                </p>
            <?php endif; ?>

            <button type="submit">Save Changes</button>
        </form>
    </div>
</div>
</body>
</html>
